/**
 * db.ts — shared database API for the mobile app.
 * All reads / writes go through http://localhost:3001 (json-server).
 *
 * On a real device, replace DB_BASE_URL with your machine's LAN IP, e.g.:
 *   http://192.168.1.x:3001
 */

export const DB_BASE_URL = 'http://192.168.2.25:3001';

// ── Generic fetch helpers ────────────────────────────────────────────────────

async function get<T>(path: string): Promise<T> {
    const res = await fetch(`${DB_BASE_URL}${path}`);
    if (!res.ok) throw new Error(`GET ${path} failed: ${res.status}`);
    return res.json();
}

async function post<T>(path: string, body: object): Promise<T> {
    const res = await fetch(`${DB_BASE_URL}${path}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    });
    if (!res.ok) throw new Error(`POST ${path} failed: ${res.status}`);
    return res.json();
}

async function patch<T>(path: string, body: object): Promise<T> {
    const res = await fetch(`${DB_BASE_URL}${path}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    });
    if (!res.ok) throw new Error(`PATCH ${path} failed: ${res.status}`);
    return res.json();
}

// ── Clients ──────────────────────────────────────────────────────────────────

export interface DBClient {
    id: number | string;
    name: string;
    kidsName?: string;
    guardian?: string;
    guardianLastName?: string;
    dob?: string;
    status?: string;
    services?: { serviceId: string; hours: string }[];
    phones?: { id: string; value: string; type: string; isPrimary: boolean }[];
    emails?: { id: string; value: string; type: string; isPrimary: boolean }[];
    addresses?: { id: string; value: string; type: string; isPrimary: boolean }[];
    teacher?: string;
    iepMeeting?: string;
}

export const fetchClients = () => get<DBClient[]>('/clients');

// ── Available Services ───────────────────────────────────────────────────────

export interface DBService {
    id: string;
    serviceId: string;
    name: string;
    provider: string;
}

export const fetchAvailableServices = () => get<DBService[]>('/available_services');

// ── Sessions ─────────────────────────────────────────────────────────────────

export interface DBSession {
    id?: string | number;
    sessionId?: string;  // Random SES-XXXXXX display ID
    userId?: string;
    workerName?: string;
    employeeName?: string;
    employeeId?: string;
    clientId: string | number;
    clientName: string;
    clientStatus?: string;
    serviceType: string;
    startTime: string;
    endTime?: string;
    durationSeconds: number;
    status: 'active' | 'completed';
    notes?: string;
    documents?: any[];
    route?: any[];
    signature?: string;
    signedAt?: string;
}

export const fetchSessions = () => get<DBSession[]>('/sessions');
export const createSession = (s: Omit<DBSession, 'id'>) => post<DBSession>('/sessions', s);
export const updateSession = (id: string | number, s: Partial<DBSession>) => patch<DBSession>(`/sessions/${id}`, s);

// ── Providers ────────────────────────────────────────────────────────────────

export interface DBProvider {
    id: string;
    name: string;
    color: string;
    textColor: string;
}

export const fetchProviders = () => get<DBProvider[]>('/providers');
