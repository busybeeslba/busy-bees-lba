import React, { useState } from 'react';
import {
    View, Text, StyleSheet, TextInput,
    TouchableOpacity, Alert, ActivityIndicator,
    Keyboard, TouchableWithoutFeedback, Platform
} from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../types/navigation';
import { useAppStore } from '../../store/useAppStore';
import { COLORS, FONTS } from '../../constants/theme';
import { ArrowLeft, Save, Calendar } from 'lucide-react-native';
import { DB_BASE_URL } from '../../lib/db';

export const ProbeDataScreen = () => {
    const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
    const { activeSession, user, addDocument, clients } = useAppStore();

    const [saving, setSaving] = useState(false);
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [pickedDate, setPickedDate] = useState(new Date());

    const handleDateChange = (_: any, selected?: Date) => {
        if (Platform.OS === 'android') setShowDatePicker(false);
        if (selected) {
            setPickedDate(selected);
            setForm(f => ({ ...f, date: selected.toISOString().slice(0, 10) }));
        }
    };

    // Look up the full client record to get assignedPrograms
    const numericClientId = activeSession?.clientId?.replace('CLI-', '');
    const clientRecord = clients.find(c => String(c.id) === numericClientId);

    // Pre-populate from the active session and logged-in user
    const [form, setForm] = useState({
        clientId: activeSession?.clientId || '',
        clientName: activeSession?.clientName || '',
        employeeName: user?.name || '',
        employeeId: user?.employeeId || '',
        program: (clientRecord as any)?.assignedPrograms || activeSession?.serviceType || '',
        sto: '',
        date: new Date().toISOString().slice(0, 10),
        status: 'Success',
        timestamp: new Date().toISOString(),
    });

    const handleSave = async () => {
        if (!form.sto.trim()) {
            Alert.alert('Validation Error', 'Please fill in the Short-Term Objectives field.');
            return;
        }
        setSaving(true);
        try {
            const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
            const rowId = 'ROW-' + Array.from({ length: 5 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
            const payload = { rowId, ...form, timestamp: new Date().toISOString() };
            const res = await fetch(`${DB_BASE_URL}/probes`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            if (!res.ok) throw new Error('Network response was not ok');
            const saved = await res.json();

            // Record this form in the session's document list
            addDocument({
                id: String(saved.id || Date.now()),
                templateType: 'probe',
                type: 'Probe Data',
                createdAt: new Date().toISOString(),
                pdfUrl: `probe_${saved.id}.pdf`,
            });

            Alert.alert('Success', 'Probe data saved successfully!', [
                { text: 'OK', onPress: () => navigation.goBack() }
            ]);
        } catch (err) {
            console.error('Save error:', err);
            Alert.alert('Error', 'Failed to save. Please ensure the shared database is running on port 3001.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
            <View style={styles.container}>
                <View style={styles.header}>
                    <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
                        <ArrowLeft size={24} color={COLORS.textLight} />
                    </TouchableOpacity>
                    <Text style={styles.headerTitle}>Probe Data</Text>
                    <View style={{ width: 24 }} />
                </View>

                <KeyboardAwareScrollView
                    contentContainerStyle={styles.scroll}
                    keyboardShouldPersistTaps="handled"
                    showsVerticalScrollIndicator={false}
                    enableOnAndroid={true}
                    extraScrollHeight={120}
                >
                    <View style={styles.infoBanner}>
                        <Text style={styles.infoText}>
                            🔒 Client and employee info are locked — pre-filled from your active session.
                        </Text>
                    </View>

                    <Text style={styles.sectionTitle}>Client</Text>
                    <View style={styles.lockedGroup}>
                        <View style={styles.lockedRow}>
                            <Text style={styles.lockedLabel}>Client Name</Text>
                            <Text style={styles.lockedValue}>{form.clientName || '—'}</Text>
                        </View>
                        <View style={styles.lockedRow}>
                            <Text style={styles.lockedLabel}>Client ID</Text>
                            <Text style={styles.lockedValue}>{form.clientId || '—'}</Text>
                        </View>
                    </View>

                    <Text style={styles.sectionTitle}>Employee</Text>
                    <View style={styles.lockedGroup}>
                        <View style={styles.lockedRow}>
                            <Text style={styles.lockedLabel}>Employee Name</Text>
                            <Text style={styles.lockedValue}>{form.employeeName || '—'}</Text>
                        </View>
                        <View style={styles.lockedRow}>
                            <Text style={styles.lockedLabel}>Employee ID</Text>
                            <Text style={styles.lockedValue}>{form.employeeId || '—'}</Text>
                        </View>
                    </View>

                    <Text style={styles.sectionTitle}>Program & Objectives</Text>
                    <View style={styles.formGroup}>
                        <Text style={styles.label}>Program</Text>
                        <TextInput style={styles.input} value={form.program}
                            onChangeText={t => setForm({ ...form, program: t })}
                            placeholder="e.g. Math Readiness" placeholderTextColor={COLORS.secondaryTextDark} />
                    </View>
                    <View style={styles.formGroup}>
                        <Text style={styles.label}>Short-Term Objectives (STO) *</Text>
                        <TextInput style={[styles.input, styles.textArea]} value={form.sto}
                            onChangeText={t => setForm({ ...form, sto: t })}
                            placeholder="Describe short-term objectives..."
                            placeholderTextColor={COLORS.secondaryTextDark}
                            multiline numberOfLines={4} />
                    </View>

                    <Text style={styles.sectionTitle}>Result</Text>
                    <View style={styles.formGroup}>
                        <Text style={styles.label}>Date</Text>
                        <TouchableOpacity
                            style={styles.dateRow}
                            onPress={() => setShowDatePicker(true)}
                            activeOpacity={0.7}
                        >
                            <Text style={styles.dateText}>{form.date}</Text>
                            <Calendar size={20} color={COLORS.primary} />
                        </TouchableOpacity>
                        {showDatePicker && (
                            <DateTimePicker
                                value={pickedDate}
                                mode="date"
                                display={Platform.OS === 'ios' ? 'inline' : 'default'}
                                onChange={handleDateChange}
                                maximumDate={new Date()}
                            />
                        )}
                        {showDatePicker && Platform.OS === 'ios' && (
                            <TouchableOpacity
                                style={styles.doneDateBtn}
                                onPress={() => setShowDatePicker(false)}
                            >
                                <Text style={styles.doneDateText}>Done</Text>
                            </TouchableOpacity>
                        )}
                    </View>
                    <View style={styles.formGroup}>
                        <Text style={styles.label}>Status</Text>
                        <View style={styles.segmentRow}>
                            {(['Success', 'Failed'] as const).map(opt => (
                                <TouchableOpacity
                                    key={opt}
                                    style={[
                                        styles.segmentBtn,
                                        form.status === opt && {
                                            backgroundColor: opt === 'Success' ? '#10B981' : COLORS.error,
                                            borderColor: opt === 'Success' ? '#10B981' : COLORS.error,
                                        }
                                    ]}
                                    onPress={() => setForm({ ...form, status: opt })}
                                >
                                    <Text style={[
                                        styles.segmentText,
                                        form.status === opt && { color: COLORS.white }
                                    ]}>{opt}</Text>
                                </TouchableOpacity>
                            ))}
                        </View>
                    </View>
                </KeyboardAwareScrollView>

                <View style={styles.footer}>
                    <TouchableOpacity
                        style={[styles.saveBtn, saving && { opacity: 0.7 }]}
                        onPress={handleSave} disabled={saving}>
                        {saving
                            ? <ActivityIndicator color={COLORS.white} />
                            : <><Save size={20} color={COLORS.white} /><Text style={styles.saveBtnText}>Save Probe Data</Text></>
                        }
                    </TouchableOpacity>
                </View>
            </View>
        </TouchableWithoutFeedback>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: COLORS.backgroundLight },
    header: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        paddingHorizontal: 16, paddingTop: 16, paddingBottom: 16,
        backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.borderLight,
    },
    backBtn: { padding: 4 },
    headerTitle: { fontSize: 18, fontFamily: FONTS.bold, color: COLORS.textLight },
    infoBanner: {
        margin: 16, padding: 12, backgroundColor: '#e8f4fd',
        borderRadius: 10, borderLeftWidth: 4, borderLeftColor: COLORS.primary,
    },
    infoText: { fontSize: 13, fontFamily: FONTS.regular, color: '#1e3a5f', lineHeight: 18 },
    sectionTitle: {
        fontSize: 15, fontFamily: FONTS.bold, color: COLORS.primary,
        marginTop: 8, marginBottom: 12, paddingHorizontal: 16,
    },
    scroll: { paddingBottom: 40 },
    formGroup: { marginBottom: 16, paddingHorizontal: 16 },
    label: { fontSize: 13, fontFamily: FONTS.medium, color: COLORS.textLight, marginBottom: 6 },
    input: {
        backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.borderLight,
        borderRadius: 10, paddingHorizontal: 14, height: 48,
        fontFamily: FONTS.regular, fontSize: 15, color: COLORS.textLight,
    },
    textArea: { height: 100, paddingVertical: 12, textAlignVertical: 'top' },
    dateRow: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.borderLight,
        borderRadius: 10, paddingHorizontal: 14, height: 48,
    },
    dateText: { fontSize: 15, fontFamily: FONTS.regular, color: COLORS.textLight },
    doneDateBtn: {
        marginTop: 8, alignSelf: 'flex-end',
        paddingHorizontal: 20, paddingVertical: 8,
        backgroundColor: COLORS.primary, borderRadius: 8,
    },
    doneDateText: { fontFamily: FONTS.bold, color: COLORS.white, fontSize: 14 },
    segmentRow: { flexDirection: 'row', gap: 12 },
    segmentBtn: {
        flex: 1, height: 48, borderRadius: 10, borderWidth: 1.5,
        borderColor: COLORS.borderLight, alignItems: 'center', justifyContent: 'center',
        backgroundColor: COLORS.white,
    },
    segmentText: { fontSize: 15, fontFamily: FONTS.semiBold, color: COLORS.textLight },
    footer: {
        padding: 16, backgroundColor: COLORS.white,
        borderTopWidth: 1, borderTopColor: COLORS.borderLight,
    },
    saveBtn: {
        height: 54, backgroundColor: COLORS.primary, borderRadius: 12,
        flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    },
    saveBtnText: { fontSize: 17, fontFamily: FONTS.bold, color: COLORS.white },
    lockedGroup: {
        marginHorizontal: 16, marginBottom: 16,
        backgroundColor: '#f1f5f9', borderRadius: 12,
        borderWidth: 1, borderColor: '#e2e8f0', overflow: 'hidden',
    },
    lockedRow: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        paddingHorizontal: 16, paddingVertical: 13,
        borderBottomWidth: 1, borderBottomColor: '#e2e8f0',
    },
    lockedLabel: { fontSize: 13, fontFamily: FONTS.medium, color: '#94a3b8' },
    lockedValue: { fontSize: 14, fontFamily: FONTS.semiBold, color: '#1e293b' },
});
