import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Animated, Alert } from 'react-native';
import { ScreenLayout } from '../../components/ScreenLayout';
import { DashboardHeader } from '../../components/DashboardHeader';
import { useAppStore } from '../../store/useAppStore';
import { COLORS, FONTS } from '../../constants/theme';
import { Play, MapPin, LocateFixed, Plus, Minus, Navigation } from 'lucide-react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../types/navigation';
import { TouchableOpacity } from 'react-native';
import * as Location from 'expo-location';
import { MapComponent } from '../../components/MapComponent';

import { useTheme } from '../../hooks/useTheme';

export const DashboardScreen = () => {
    const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
    const { isGPSActive, currentLocation, updateLocation, activeSession } = useAppStore();
    const locationInterval = useRef<NodeJS.Timeout | null>(null);
    const [initialLocation, setInitialLocation] = useState<{ lat: number, lng: number } | null>(null);
    const [permissionStatus, setPermissionStatus] = useState<string>('undetermined');

    // Theme Hook
    const { colors, isDarkMode } = useTheme();

    // Pulse Animation
    const pulseAnim = useRef(new Animated.Value(1)).current;

    // Request permissions on mount
    useEffect(() => {
        (async () => {
            try {
                const { status } = await Location.requestForegroundPermissionsAsync();
                setPermissionStatus(status);
                if (status !== 'granted') {
                    // fall back to San Francisco but maybe show a visual warning?
                    return;
                }

                // Get initial fix
                const location = await Location.getCurrentPositionAsync({});
                updateLocation({
                    latitude: location.coords.latitude,
                    longitude: location.coords.longitude,
                    accuracy: location.coords.accuracy || 0,
                    timestamp: location.timestamp,
                });
            } catch (error) {
                console.log("Error requesting permissions: ", error);
            }
        })();
    }, []);

    useEffect(() => {
        let subscription: Location.LocationSubscription | null = null;

        if (isGPSActive) {
            // Pulse Animation
            Animated.loop(
                Animated.sequence([
                    Animated.timing(pulseAnim, { toValue: 2, duration: 1000, useNativeDriver: true }),
                    Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
                ])
            ).start();

            const startTracking = async () => {
                const { status } = await Location.getForegroundPermissionsAsync();
                if (status === 'granted') {
                    try {
                        subscription = await Location.watchPositionAsync(
                            {
                                accuracy: Location.Accuracy.High,
                                timeInterval: 2000,
                                distanceInterval: 1,
                            },
                            (location) => {
                                updateLocation({
                                    latitude: location.coords.latitude,
                                    longitude: location.coords.longitude,
                                    accuracy: location.coords.accuracy || 5,
                                    timestamp: location.timestamp,
                                });
                            }
                        );
                    } catch (err) {
                        console.log("Error watching position:", err);
                    }
                } else {
                    // Permission denied/fallback mode
                    locationInterval.current = setInterval(() => {
                        const baseLat = 37.7749;
                        const baseLng = -122.4194;
                        const randomOffset = () => (Math.random() - 0.5) * 0.0001;
                        updateLocation({
                            latitude: baseLat + randomOffset(),
                            longitude: baseLng + randomOffset(),
                            accuracy: 500, // High accuracy number to indicate weak signal/mock
                            timestamp: Date.now(),
                        });
                    }, 3000);
                }
            };
            startTracking();

        } else {
            pulseAnim.setValue(1);
            if (subscription) (subscription as any).remove();
            if (locationInterval.current) clearInterval(locationInterval.current);
        }

        return () => {
            if (subscription) (subscription as any).remove();
            if (locationInterval.current) clearInterval(locationInterval.current);
        };
    }, [isGPSActive]);

    const mapRef = useRef<any>(null); // Use any to avoid complex type issues with forwards refs for now
    const [zoomLevel, setZoomLevel] = useState(0.005);

    const handleZoomIn = () => {
        const newZoom = zoomLevel / 2;
        setZoomLevel(newZoom);
        if (currentLocation && mapRef.current) {
            mapRef.current.animateToRegion({
                latitude: currentLocation.latitude,
                longitude: currentLocation.longitude,
                latitudeDelta: newZoom,
                longitudeDelta: newZoom,
            }, 500);
        }
    };

    const handleZoomOut = () => {
        const newZoom = zoomLevel * 2;
        setZoomLevel(newZoom);
        if (currentLocation && mapRef.current) {
            mapRef.current.animateToRegion({
                latitude: currentLocation.latitude,
                longitude: currentLocation.longitude,
                latitudeDelta: newZoom,
                longitudeDelta: newZoom,
            }, 500);
        }
    };

    const handleRecenter = () => {
        if (currentLocation && mapRef.current) {
            setZoomLevel(0.005); // Reset zoom
            mapRef.current.animateToRegion({
                latitude: currentLocation.latitude,
                longitude: currentLocation.longitude,
                latitudeDelta: 0.005,
                longitudeDelta: 0.005,
            }, 1000);
        }
    };

    const handleStartSession = () => {
        navigation.navigate('SessionDetails');
    };

    // Dynamic Styles for Dark Mode
    const actionSectionStyle = [styles.actionSection, { backgroundColor: colors.background, borderBottomColor: colors.border }];
    const mapHeaderStyle = [styles.mapHeader, { backgroundColor: isDarkMode ? '#111827' : 'rgba(249,250,251,0.9)', borderBottomColor: colors.border }];
    const mapTitleStyle = [styles.mapTitle, { color: colors.text }];
    const controlBtnStyle = [styles.controlBtn, { backgroundColor: isDarkMode ? '#1f2937' : 'rgba(255,255,255,0.9)', borderColor: isDarkMode ? '#374151' : 'rgba(255,255,255,0.2)' }];
    const controlIconColor = isDarkMode ? '#e5e7eb' : COLORS.textLight;
    const infoCardStyle = [styles.infoCard, { backgroundColor: isDarkMode ? '#1f2937' : 'rgba(255,255,255,0.95)', borderColor: colors.border }];
    const iconBoxStyle = [styles.locationIconBox, { backgroundColor: isDarkMode ? '#374151' : COLORS.backgroundLight }];
    const labelStyle = [styles.coordsLabel, { color: colors.secondaryText }];
    const valueStyle = [styles.coordsValue, { color: colors.text }];

    return (
        <ScreenLayout>
            <DashboardHeader />

            {/* Start Session Button Area (Top Section from Design) */}
            <View style={actionSectionStyle}>
                <TouchableOpacity
                    style={styles.startBtn}
                    onPress={handleStartSession}
                    activeOpacity={0.9}
                >
                    <View style={styles.iconCircle}>
                        <Play size={48} color={COLORS.white} fill={COLORS.white} />
                    </View>
                    <Text style={styles.startTitle}>
                        {activeSession ? "RETURN TO SESSION" : "START NEW SESSION"}
                    </Text>
                    <Text style={styles.startSubtitle}>Ready to clock in?</Text>
                </TouchableOpacity>
            </View>

            {/* Live Tracking Map Area */}
            <View style={styles.mapSection}>
                {/* Map Header */}
                <View style={mapHeaderStyle}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                        <MapPin size={20} color={COLORS.primary} />
                        <Text style={mapTitleStyle}>LIVE TRACKING</Text>
                    </View>
                    {isGPSActive && (
                        <View style={styles.badge}>
                            <View style={styles.dot} />
                            <Text style={styles.badgeText}>GPS ACTIVE</Text>
                        </View>
                    )}
                </View>

                {/* Map Content (Interactive) */}
                <View style={[styles.mapContainer, { backgroundColor: isDarkMode ? '#374151' : '#E5E7EB' }]}>
                    <MapComponent ref={mapRef} currentLocation={currentLocation} />

                    {/* Map Controls */}
                    <View style={styles.mapControls}>
                        <TouchableOpacity style={controlBtnStyle} onPress={handleZoomIn}>
                            <Plus size={20} color={controlIconColor} />
                        </TouchableOpacity>
                        <TouchableOpacity style={controlBtnStyle} onPress={handleZoomOut}>
                            <Minus size={20} color={controlIconColor} />
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={[styles.controlBtn, { backgroundColor: COLORS.primary, borderColor: COLORS.primary }]}
                            onPress={handleRecenter}
                        >
                            <Navigation size={20} color={COLORS.white} />
                        </TouchableOpacity>
                    </View>

                    {/* Bottom Info Card */}
                    {useAppStore(state => state.showCoordinates) && (
                        <View style={infoCardStyle}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                                <View style={iconBoxStyle}>
                                    <LocateFixed size={20} color={COLORS.primary} />
                                </View>
                                <View>
                                    <Text style={labelStyle}>CURRENT COORDINATES</Text>
                                    <Text style={valueStyle}>
                                        {currentLocation
                                            ? `${currentLocation.latitude.toFixed(6)}, ${currentLocation.longitude.toFixed(6)}`
                                            : "Waiting for signal..."}
                                    </Text>
                                </View>
                            </View>
                            <View style={{ alignItems: 'flex-end' }}>
                                <Text style={labelStyle}>ACCURACY</Text>
                                <Text style={[styles.coordsLabel, { color: COLORS.success, fontSize: 12 }]}>± {currentLocation?.accuracy ? Math.round(currentLocation.accuracy) : 3} meters</Text>
                            </View>
                        </View>
                    )}
                </View>
            </View>
        </ScreenLayout>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.backgroundLight,
    },
    actionSection: {
        paddingVertical: 48,
        paddingTop: 64, // Extra top padding for visually pushing it down
        paddingHorizontal: 24,
        alignItems: 'center',
        backgroundColor: COLORS.white,
        borderBottomWidth: 1,
        borderBottomColor: COLORS.borderLight,
        zIndex: 10,
    },
    startBtn: {
        backgroundColor: COLORS.primary,
        borderRadius: 32,
        paddingVertical: 32,
        paddingHorizontal: 24,
        width: '100%',
        maxWidth: 320,
        alignItems: 'center',
        shadowColor: COLORS.primary,
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.3,
        shadowRadius: 20,
        elevation: 10,
    },
    iconCircle: {
        backgroundColor: 'rgba(255,255,255,0.2)',
        padding: 16,
        borderRadius: 50,
        marginBottom: 16,
    },
    startTitle: {
        fontFamily: FONTS.bold, // Inter-ExtraBold equivalent
        fontSize: 20,
        color: COLORS.white,
        letterSpacing: 0.5,
    },
    startSubtitle: {
        fontFamily: FONTS.medium,
        fontSize: 14,
        color: 'rgba(255,255,255,0.7)',
        marginTop: 4,
    },
    mapSection: {
        flex: 1,
        flexDirection: 'column',
    },
    mapHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 16,
        paddingVertical: 12,
        backgroundColor: 'rgba(249,250,251,0.9)', // gray-50 backdrop
        borderBottomWidth: 1,
        borderBottomColor: COLORS.borderLight,
    },
    mapTitle: {
        fontFamily: FONTS.bold,
        fontSize: 14,
        color: COLORS.textLight,
        letterSpacing: 1,
    },
    badge: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'rgba(34,197,94,0.1)',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 4,
        gap: 6,
    },
    dot: {
        width: 6,
        height: 6,
        borderRadius: 3,
        backgroundColor: COLORS.success,
    },
    badgeText: {
        fontSize: 10,
        fontFamily: FONTS.bold,
        color: COLORS.success,
    },
    mapContainer: {
        flex: 1,
        position: 'relative',
        backgroundColor: '#E5E7EB',
    },
    mapBg: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: '#d1d5db', // Placeholder gray
    },
    centerMarker: {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: [{ translateX: -16 }, { translateY: -16 }], // Center 32px
        alignItems: 'center',
        justifyContent: 'center',
    },
    userDot: {
        width: 20,
        height: 20,
        backgroundColor: COLORS.primary,
        borderRadius: 10,
        borderWidth: 3,
        borderColor: COLORS.white,
        zIndex: 2,
    },
    pulseRing: {
        position: 'absolute',
        width: 32,
        height: 32,
        backgroundColor: COLORS.primary,
        borderRadius: 16,
        zIndex: 1,
    },
    mapControls: {
        position: 'absolute',
        top: 16,
        right: 16,
        gap: 8,
    },
    controlBtn: {
        width: 40,
        height: 40,
        backgroundColor: 'rgba(255,255,255,0.9)',
        borderRadius: 12,
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 1,
        borderColor: 'rgba(255,255,255,0.2)',
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 2,
    },
    infoCard: {
        position: 'absolute',
        bottom: 100, // Increased to clear TabBar (approx 80px)
        left: 16,
        right: 16,
        backgroundColor: 'rgba(255,255,255,0.95)',
        borderRadius: 16,
        padding: 16,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 10,
        elevation: 5,
        borderWidth: 1,
        borderColor: COLORS.borderLight,
    },
    locationIconBox: {
        padding: 8,
        backgroundColor: COLORS.backgroundLight,
        borderRadius: 8,
    },
    coordsLabel: {
        fontSize: 10,
        fontFamily: FONTS.bold,
        color: COLORS.secondaryTextLight,
        marginBottom: 2,
    },
    coordsValue: {
        fontSize: 14,
        fontFamily: FONTS.bold, // Monospace ideally
        color: COLORS.textLight,
    }
});
