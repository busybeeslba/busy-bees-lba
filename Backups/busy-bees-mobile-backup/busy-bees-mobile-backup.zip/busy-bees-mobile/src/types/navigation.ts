import { NavigatorScreenParams } from '@react-navigation/native';
import { Session, GeneratedDocument } from '../types';

export type AuthStackParamList = {
    Login: undefined;
};

export type MainTabParamList = {
    Dashboard: undefined;
    Calendar: undefined;
    History: undefined;
    Settings: undefined;
};

export type RootStackParamList = {
    Auth: NavigatorScreenParams<AuthStackParamList>;
    Main: NavigatorScreenParams<MainTabParamList>;
    SessionDetails: undefined;
    DocumentTemplatePicker: undefined;
    DocumentForm: { templateType: string };
    CompleteSession: undefined;
    SessionCompleted: { session: Session };
    HistoryDetails: { session: Session };
    EditProfile: undefined;
    SetAvailability: undefined;
};
