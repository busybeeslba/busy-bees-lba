export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  phoneNumber?: string;
  employeeId?: string;
}

export type SessionStatus = 'active' | 'completed';

export interface LocationPoint {
  latitude: number;
  longitude: number;
  timestamp: number;
  accuracy: number;
}

export interface GeneratedDocument {
  id: string;
  templateType: string;
  type: string; // "Site Assessment", "Maintenance Checklist", etc.
  createdAt: string;
  pdfUrl: string; // mock url
}

export interface Session {
  id: string;
  clientId: string;
  clientName: string;
  serviceType: string;
  startTime: string; // ISO string
  endTime?: string; // ISO string
  durationSeconds: number;
  status: SessionStatus;
  notes?: string;
  documents: GeneratedDocument[];
  signature?: string; // mock signature data/url
  signedAt?: string;
  route: LocationPoint[];
}

export interface AppState {
  // User State
  user: User | null;
  isLoggedIn: boolean;
  login: (user: User) => void;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
  availability: any[];
  setAvailability: (slots: any[]) => void;

  // Session State
  activeSession: Session | null;
  completedSessions: Session[];

  // Actions
  startSession: (arg1: any, arg2?: string, arg3?: string) => void; // Supports legacy (clientId, name, service) or object ({clientName, service, notes})
  updateActiveSession: (updates: Partial<Session>) => void;
  updateSessionNotes: (sessionId: string, notes: string) => void;

  // Document Management
  addDocumentToSession: (doc: GeneratedDocument) => void; // Deprecated/Internal alias
  addDocument: (doc: GeneratedDocument) => void;
  removeDocument: (sessionId: string, docId: string) => void;

  completeSession: (signature: string) => void;
  endSession: () => void; // Alias for completeSession with empty signature

  // GPS Simulation State (Local to store for simplicity in this MVP)
  isGPSActive: boolean;
  currentLocation: LocationPoint | null;
  updateLocation: (point: LocationPoint) => void;
  toggleGPS: (active: boolean) => void;

  // Settings
  showCoordinates: boolean;
  toggleShowCoordinates: (show: boolean) => void;

  isDarkMode: boolean;
  toggleDarkMode: (enabled: boolean) => void;

  notificationsEnabled: boolean;
  toggleNotifications: (enabled: boolean) => void;
}
