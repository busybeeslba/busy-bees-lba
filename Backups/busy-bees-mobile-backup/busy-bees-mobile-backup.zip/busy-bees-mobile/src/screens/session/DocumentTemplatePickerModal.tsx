import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Modal } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../types/navigation';
import { COLORS, FONTS } from '../../constants/theme';
import { FileText, ClipboardCheck, Briefcase, X } from 'lucide-react-native';

const templates = [
    { id: 'site_assessment', name: 'Site Assessment', icon: ClipboardCheck, color: '#3B82F6' },
    { id: 'maintenance_checklist', name: 'Maintenance Checklist', icon: Briefcase, color: '#10B981' },
    { id: 'work_completion', name: 'Work Completion Report', icon: FileText, color: '#F59E0B' },
];

export const DocumentTemplatePickerModal = () => {
    const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();

    const handleSelect = (templateId: string) => {
        navigation.replace('DocumentForm', { templateId });
    };

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.title}>Select Document Template</Text>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <X size={24} color={COLORS.textLight} />
                </TouchableOpacity>
            </View>

            <FlatList
                data={templates}
                keyExtractor={item => item.id}
                contentContainerStyle={styles.list}
                renderItem={({ item }) => (
                    <TouchableOpacity
                        style={styles.item}
                        onPress={() => handleSelect(item.id)}
                        activeOpacity={0.7}
                    >
                        <View style={[styles.iconBox, { backgroundColor: `${item.color}20` }]}> {/* 20 = 12% opacity hex */}
                            <item.icon size={24} color={item.color} />
                        </View>
                        <View style={styles.itemInfo}>
                            <Text style={styles.itemName}>{item.name}</Text>
                            <Text style={styles.itemSub}>Click to generate form</Text>
                        </View>
                        <View style={styles.arrowBox}>
                            <Text style={styles.arrow}>{'>'}</Text>
                        </View>
                    </TouchableOpacity>
                )}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.backgroundLight,
        paddingTop: 20,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 24,
        paddingBottom: 24,
    },
    title: {
        fontSize: 20,
        fontFamily: FONTS.bold,
        color: COLORS.textLight,
    },
    list: {
        paddingHorizontal: 24,
    },
    item: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: COLORS.white,
        marginBottom: 16,
        padding: 16,
        borderRadius: 16,
        shadowColor: '#000',
        shadowOpacity: 0.05,
        shadowRadius: 4,
        elevation: 2,
    },
    iconBox: {
        width: 48,
        height: 48,
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 16,
    },
    itemInfo: {
        flex: 1,
    },
    itemName: {
        fontSize: 16,
        fontFamily: FONTS.semiBold,
        color: COLORS.textLight,
        marginBottom: 4,
    },
    itemSub: {
        fontSize: 12,
        fontFamily: FONTS.medium,
        color: COLORS.secondaryTextLight,
    },
    arrowBox: {
        width: 32,
        height: 32,
        justifyContent: 'center',
        alignItems: 'center',
    },
    arrow: {
        fontSize: 20,
        color: COLORS.borderLight,
        fontWeight: 'bold',
    }
});
