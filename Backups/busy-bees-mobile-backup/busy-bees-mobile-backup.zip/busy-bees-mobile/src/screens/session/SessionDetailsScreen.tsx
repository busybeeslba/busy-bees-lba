import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, TextInput, Alert, Platform } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { RootStackParamList } from '../../types/navigation';
import { useAppStore } from '../../store/useAppStore';
import { ScreenLayout } from '../../components/ScreenLayout';
import { COLORS, FONTS } from '../../constants/theme';
import { ChevronDown, Paperclip, FileText, Image as ImageIcon, Trash2, Square } from 'lucide-react-native';
import { useTheme } from '../../hooks/useTheme';

export const SessionDetailsScreen = () => {
    const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
    const insets = useSafeAreaInsets();
    const { colors, isDarkMode } = useTheme();
    const {
        activeSession,
        startSession,
        updateSessionNotes,
        addDocument,
        removeDocument
    } = useAppStore();

    // Local state for dropdowns mock
    const [client, setClient] = useState(activeSession?.clientName || 'Acme Corp - North Branch');
    const [service, setService] = useState(activeSession?.serviceType || 'Maintenance');

    // Timer Logic
    const [elapsed, setElapsed] = useState(0);
    const intervalRef = useRef<NodeJS.Timeout | null>(null);

    useEffect(() => {
        if (!activeSession) {
            // Start a new session if none exists
            startSession({
                clientName: client,
                serviceType: service,
                notes: '',
            });
        }
    }, []);

    useEffect(() => {
        if (activeSession?.startTime) {
            const start = new Date(activeSession.startTime).getTime();
            intervalRef.current = setInterval(() => {
                const now = Date.now();
                setElapsed(Math.floor((now - start) / 1000));
            }, 1000);
        }
        return () => {
            if (intervalRef.current) clearInterval(intervalRef.current);
        };
    }, [activeSession?.startTime]);

    const formatTime = (totalSeconds: number) => {
        const h = Math.floor(totalSeconds / 3600);
        const m = Math.floor((totalSeconds % 3600) / 60);
        const s = totalSeconds % 60;
        return {
            h: h.toString().padStart(2, '0'),
            m: m.toString().padStart(2, '0'),
            s: s.toString().padStart(2, '0')
        };
    };

    const time = formatTime(elapsed);

    const handleAddDocument = () => {
        navigation.navigate('DocumentTemplatePicker');
    };

    const handleEndSession = () => {
        if (activeSession) {
            updateSessionNotes(activeSession.id, activeSession.notes || '');
            navigation.navigate('CompleteSession');
        }
    };

    const handleUpdateNotes = (text: string) => {
        if (activeSession) {
            updateSessionNotes(activeSession.id, text);
        }
    }

    if (!activeSession) return null;

    // Dynamic Styles
    const dropdownStyle = [styles.dropdown, { backgroundColor: colors.card, borderColor: colors.border }];
    const dropdownTextStyle = [styles.dropdownText, { color: colors.text }];
    const sectionTitleStyle = [styles.sectionTitle, { color: colors.text }];
    const timerBoxStyle = [styles.timerBox, { backgroundColor: colors.card, borderColor: colors.border }];
    const timerValueStyle = [styles.timerValue, { color: colors.text }];
    const textAreaStyle = [styles.textArea, { backgroundColor: colors.card, borderColor: colors.border, color: colors.text }];
    const docItemStyle = [styles.docItem, { backgroundColor: colors.card, borderColor: colors.border }];
    const docNameStyle = [styles.docName, { color: colors.text }];

    // Footer needs special handling for safe area
    const footerStyle = [
        styles.footer,
        {
            backgroundColor: isDarkMode ? colors.card : 'rgba(255,255,255,0.9)',
            borderTopColor: colors.border,
            paddingBottom: insets.bottom + 24
        }
    ];

    return (
        <ScreenLayout useSafePadding={false}>
            <View style={{ flex: 1 }}>
                <KeyboardAwareScrollView
                    style={{ flex: 1 }}
                    contentContainerStyle={styles.scroll}
                    enableOnAndroid={true}
                    extraScrollHeight={120} // Push it up nicely
                    keyboardShouldPersistTaps="handled"
                >

                    {/* Client Dropdown */}
                    <View style={[styles.section, { marginTop: 24 }]}>
                        <Text style={[styles.label, { color: colors.secondaryText }]}>CLIENT</Text>
                        <TouchableOpacity style={dropdownStyle}>
                            <Text style={dropdownTextStyle}>{client}</Text>
                            <ChevronDown size={20} color={colors.secondaryText} />
                        </TouchableOpacity>
                    </View>

                    {/* Timer Section */}
                    <View style={styles.timerContainer}>
                        <Text style={[styles.label, { color: colors.secondaryText }]}>ELAPSED TIME</Text>
                        <View style={styles.timerRow}>
                            <View style={styles.timerBlock}>
                                <View style={timerBoxStyle}>
                                    <Text style={timerValueStyle}>{time.h}</Text>
                                </View>
                                <Text style={styles.timerLabel}>HOURS</Text>
                            </View>
                            <Text style={styles.colon}>:</Text>
                            <View style={styles.timerBlock}>
                                <View style={timerBoxStyle}>
                                    <Text style={timerValueStyle}>{time.m}</Text>
                                </View>
                                <Text style={styles.timerLabel}>MINUTES</Text>
                            </View>
                            <Text style={styles.colon}>:</Text>
                            <View style={styles.timerBlock}>
                                <View style={timerBoxStyle}>
                                    <Text style={timerValueStyle}>{time.s}</Text>
                                </View>
                                <Text style={styles.timerLabel}>SECONDS</Text>
                            </View>
                        </View>
                    </View>

                    {/* Service Dropdown */}
                    <View style={styles.section}>
                        <Text style={[styles.label, { color: colors.secondaryText }]}>SERVICE TYPE</Text>
                        <TouchableOpacity style={dropdownStyle}>
                            <Text style={dropdownTextStyle}>{service}</Text>
                            <ChevronDown size={20} color={colors.secondaryText} />
                        </TouchableOpacity>
                    </View>

                    {/* Session Summary / Notes */}
                    <View style={styles.section}>
                        <Text style={sectionTitleStyle}>Session Summary</Text>
                        <TextInput
                            style={textAreaStyle}
                            placeholder="Enter work details, progress updates, and field notes here..."
                            placeholderTextColor={colors.secondaryText}
                            multiline
                            textAlignVertical="top"
                            value={activeSession.notes}
                            onChangeText={handleUpdateNotes}
                        />
                    </View>

                    {/* Documents Section */}
                    <View style={styles.section}>
                        <Text style={sectionTitleStyle}>Documents</Text>
                        <TouchableOpacity style={styles.addDocBtn} onPress={handleAddDocument}>
                            <Paperclip size={20} color={COLORS.primary} />
                            <Text style={styles.addDocText}>Add a Document</Text>
                        </TouchableOpacity>

                        <View style={styles.docList}>
                            {activeSession.documents.map((doc, index) => (
                                <View key={index} style={docItemStyle}>
                                    <View style={styles.docLeft}>
                                        {doc.pdfUrl.endsWith('jpg') ? (
                                            <ImageIcon size={20} color={colors.secondaryText} />
                                        ) : (
                                            <FileText size={20} color={colors.secondaryText} />
                                        )}
                                        <View style={{ marginLeft: 12 }}>
                                            <Text style={docNameStyle}>{doc.type}</Text>
                                            <Text style={styles.docSize}>1.2 MB</Text>
                                        </View>
                                    </View>
                                    <TouchableOpacity onPress={() => removeDocument(activeSession.id, doc.id)}>
                                        <Trash2 size={20} color={COLORS.error} />
                                    </TouchableOpacity>
                                </View>
                            ))}
                        </View>
                    </View>

                </KeyboardAwareScrollView>

                {/* Bottom Action Footer */}
                <View style={footerStyle}>
                    <TouchableOpacity style={styles.endBtn} onPress={handleEndSession}>
                        <Square size={20} color={COLORS.white} fill={COLORS.white} />
                        <Text style={styles.endBtnText}>End Session</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </ScreenLayout>
    );
};

const styles = StyleSheet.create({
    scroll: {
        flexGrow: 1,
        paddingBottom: 150, // Moved here from inline style for cleanliness
    },
    section: {
        paddingHorizontal: 16,
        marginTop: 24,
    },
    label: {
        fontSize: 12,
        fontFamily: FONTS.semiBold,
        letterSpacing: 1,
        marginBottom: 8,
        textTransform: 'uppercase',
    },
    dropdown: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: 56,
        borderRadius: 12,
        paddingHorizontal: 16,
        borderWidth: 1,
    },
    dropdownText: {
        fontSize: 16,
        fontFamily: FONTS.medium,
    },
    timerContainer: {
        marginTop: 24,
        alignItems: 'center',
    },
    timerRow: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        gap: 16,
    },
    timerBlock: {
        alignItems: 'center',
        gap: 8,
    },
    timerBox: {
        width: 64,
        height: 64,
        borderRadius: 12,
        borderWidth: 1,
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: '#000',
        shadowOpacity: 0.05,
        shadowRadius: 4,
        elevation: 2,
    },
    timerValue: {
        fontSize: 28, // ~3xl
        fontFamily: FONTS.bold,
    },
    timerLabel: {
        fontSize: 10,
        fontFamily: FONTS.medium,
        color: COLORS.secondaryTextLight, // Static for now as it's secondary
        textTransform: 'uppercase',
    },
    colon: {
        fontSize: 24,
        fontFamily: FONTS.bold,
        color: COLORS.secondaryTextDark,
        marginTop: 16,
    },
    sectionTitle: {
        fontSize: 16,
        fontFamily: FONTS.semiBold,
        marginBottom: 12,
    },
    textArea: {
        borderWidth: 1,
        borderRadius: 12,
        padding: 16,
        height: 140,
        fontSize: 16,
        fontFamily: FONTS.regular,
    },
    addDocBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        height: 56,
        backgroundColor: 'rgba(19, 127, 236, 0.1)', // Primary / 10
        borderRadius: 12,
        borderWidth: 1,
        borderColor: 'rgba(19, 127, 236, 0.2)',
        gap: 12,
        marginBottom: 16,
    },
    addDocText: {
        fontSize: 16,
        fontFamily: FONTS.bold,
        color: COLORS.primary,
    },
    docList: {
        gap: 8,
    },
    docItem: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 12,
        borderRadius: 12,
        borderWidth: 1,
    },
    docLeft: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    docName: {
        fontSize: 14,
        fontFamily: FONTS.medium,
    },
    docSize: {
        fontSize: 12,
        color: COLORS.secondaryTextDark,
    },
    footer: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        padding: 16,
        borderTopWidth: 1,
    },
    endBtn: {
        height: 56,
        backgroundColor: COLORS.error,
        borderRadius: 12,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        shadowColor: COLORS.error,
        shadowOpacity: 0.3,
        shadowRadius: 8,
        elevation: 4,
    },
    endBtnText: {
        fontSize: 18,
        fontFamily: FONTS.bold,
        color: COLORS.white,
    }
});
