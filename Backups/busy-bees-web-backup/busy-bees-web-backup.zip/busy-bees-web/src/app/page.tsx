'use client';

import { Activity, Users, MapPin, Clock, FileText, CheckCircle2 } from 'lucide-react';
import styles from '@/components/dashboard/Dashboard.module.css';
import StatCard from '@/components/dashboard/StatCard';

const MOCK_ACTIVITIES = [
  { id: 1, user: 'Sarah Connor', action: 'started a session', target: 'Acme Corp', time: '2 mins ago', icon: Activity },
  { id: 2, user: 'Kyle Reese', action: 'uploaded a document', target: 'Progress Note', time: '15 mins ago', icon: FileText },
  { id: 3, user: 'Sarah Connor', action: 'completed session', target: 'Acme Corp', time: '1 hour ago', icon: CheckCircle2 },
  { id: 4, user: 'John Doe', action: 'clocked in', target: 'HQ', time: '2 hours ago', icon: Clock },
];

export default function Home() {
  return (
    <div className={styles.container}>
      <header className={styles.header}>
        <h1 className={styles.title}>Live Dashboard</h1>
        <p className={styles.subtitle}>Real-time overview of field operations.</p>
      </header>

      {/* Stats Row */}
      <div className={styles.statsGrid}>
        <StatCard
          title="Active Sessions"
          value="12"
          trend="15%"
          isPositive={true}
          icon={Activity}
        />
        <StatCard
          title="Online Staff"
          value="8"
          trend="0%"
          isPositive={true}
          icon={Users}
        />
        <StatCard
          title="Total Hours (Today)"
          value="34.5"
          trend="5%"
          isPositive={true}
          icon={Clock}
        />
      </div>

      <div className={styles.contentGrid}>
        {/* Map Section */}
        <section className={styles.mapSection}>
          <div className={styles.sectionHeader}>
            <h3 className={styles.sectionTitle}>Live Map</h3>
            <div style={{ display: 'flex', gap: '8px', fontSize: '12px', color: '#666' }}>
              <span>🟢 Active (12)</span>
              <span>⚪ Offline (3)</span>
            </div>
          </div>
          <div className={styles.mapContainer}>
            {/* Placeholder for Mapbox/Leaflet */}
            <div style={{ textAlign: 'center', color: '#666' }}>
              <MapPin size={48} style={{ marginBottom: '16px', opacity: 0.5 }} />
              <p>Interactive Map Component Loading...</p>
              <p style={{ fontSize: '12px' }}>(Mock View)</p>
            </div>

            {/* Mock Pin 1 */}
            <div style={{ position: 'absolute', top: '40%', left: '30%', backgroundColor: 'var(--primary)', padding: '8px', borderRadius: '50%', boxShadow: '0 2px 8px rgba(0,0,0,0.2)' }}>
              <Users size={16} color="black" />
            </div>
            {/* Mock Pin 2 */}
            <div style={{ position: 'absolute', top: '60%', left: '55%', backgroundColor: 'var(--primary)', padding: '8px', borderRadius: '50%', boxShadow: '0 2px 8px rgba(0,0,0,0.2)' }}>
              <Users size={16} color="black" />
            </div>
          </div>
        </section>

        {/* Activity Feed */}
        <section className={styles.feedSection}>
          <div className={styles.sectionHeader}>
            <h3 className={styles.sectionTitle}>Recent Activity</h3>
          </div>
          <ul className={styles.feedList}>
            {MOCK_ACTIVITIES.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.id} className={styles.feedItem}>
                  <div className={styles.feedIcon}>
                    <Icon size={16} color="var(--primary)" />
                  </div>
                  <div className={styles.feedContent}>
                    <h4>{item.user}</h4>
                    <p>{item.action} • <strong>{item.target}</strong></p>
                    <span className={styles.feedTime}>{item.time}</span>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      </div>
    </div>
  );
}
