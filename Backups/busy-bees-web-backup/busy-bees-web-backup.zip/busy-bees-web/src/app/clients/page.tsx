'use client';

import { useState, useRef, useEffect } from 'react';
import { Search, Plus, Phone, Mail, MapPin, Building2, X, FileText, Calendar, User, Pencil, Trash2, MoreVertical, Clock, Filter, ArrowUpDown } from 'lucide-react';
import AddClientModal from '@/components/clients/AddClientModal';
import { useDataFilter, FilterRule, MatchType } from '@/hooks/useDataFilter';
import FilterDrawer from '@/components/ui/FilterDrawer';
import FacetedFilter from '@/components/ui/FacetedFilter';
import styles from './page.module.css';
import { MOCK_AVAILABLE_SERVICES } from '@/lib/mockData';

const MOCK_CLIENTS = [
    {
        clientId: '930291',
        kidsName: 'Oliver Smith',
        guardian: 'Sarah Smith',
        address: '123 Maple Ave, Springfield',
        phone: '555-0101',
        dob: '2015-05-12',
        email: 'sarah.smith@email.com',
        teacher: 'Ms. Johnson',
        services: 'ABA Therapy',
        assignedPrograms: 'Social Skills, Daily Living',
        programPercentage: '85%',
        iepMeeting: '2024-10-15',
        status: 'Active'
    },
    {
        clientId: '849201',
        kidsName: 'Emma Davis',
        guardian: 'Michael Davis',
        address: '456 Oak Lane, Riverside',
        phone: '555-0102',
        dob: '2016-08-23',
        email: 'm.davis@email.com',
        teacher: 'Mr. Brown',
        services: 'Behavioral Intervention',
        assignedPrograms: 'Communication, aggression reduction',
        programPercentage: '72%',
        iepMeeting: '2024-11-01',
        status: 'Active'
    },
    {
        clientId: '482019',
        kidsName: 'Noah Wilson',
        guardian: 'Jennifer Wilson',
        address: '789 Pine St, Lakeside',
        phone: '555-0103',
        dob: '2014-02-14',
        email: 'jennifer.w@email.com',
        teacher: 'Mrs. Garcia',
        services: 'Social Skills Group',
        assignedPrograms: 'Peer Interaction',
        programPercentage: '90%',
        iepMeeting: '2024-09-30',
        status: 'Inactive'
    },
    {
        clientId: '593810',
        kidsName: 'Liam Martinez',
        guardian: 'David Martinez',
        address: '321 Elm St, Hilltop',
        phone: '555-0104',
        dob: '2017-11-05',
        email: 'david.m@email.com',
        teacher: 'Ms. Lee',
        schoolRelatedServices: 'Speech, PT',
        services: 'Early Intervention',
        assignedPrograms: 'Motor Skills, Vocabulary',
        programPercentage: '65%',
        iepMeeting: '2025-01-20',
        status: 'Active'
    },
];

export default function ClientsPage() {
    const [clients, setClients] = useState<typeof MOCK_CLIENTS>(MOCK_CLIENTS);
    const [selectedClient, setSelectedClient] = useState<typeof MOCK_CLIENTS[0] | null>(MOCK_CLIENTS[0]);
    const [activeActionId, setActiveActionId] = useState<string | null>(null);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [detailWidth, setDetailWidth] = useState<number>(0); // Initialize as 0, will set in effect
    const [isResizing, setIsResizing] = useState(false);
    const sidebarRef = useRef<HTMLDivElement>(null);
    const [availableServices, setAvailableServices] = useState<any[]>(MOCK_AVAILABLE_SERVICES);
    const [providers, setProviders] = useState<any[]>([]);

    const [editingClient, setEditingClient] = useState<typeof MOCK_CLIENTS[0] | null>(null);

    // Advanced Filter State
    const [filterRules, setFilterRules] = useState<FilterRule[]>([]);
    const [matchType, setMatchType] = useState<MatchType>('AND');
    const [showFilterDrawer, setShowFilterDrawer] = useState(false);

    // Sorting State
    const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' } | null>(null);

    const handleSort = (key: string) => {
        let direction: 'asc' | 'desc' = 'asc';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    // Helper to get service name
    const getServiceName = (serviceId: string) => {
        const srv = availableServices.find(s => s.serviceId === serviceId);
        return srv ? srv.name : serviceId;
    };

    // Helper to get provider name
    const getServiceProvider = (serviceId: string) => {
        const srv = availableServices.find(s => s.serviceId === serviceId);
        return srv && srv.provider ? srv.provider : 'Unassigned';
    };

    // Helper to assign consistent colors to providers
    const getProviderStyle = (providerName: string) => {
        if (!providerName || providerName === 'Unassigned') return { backgroundColor: '#94a3b8', color: '#ffffff' }; // default gray

        const pObj = providers.find(p => p.name === providerName);
        if (pObj && pObj.color) return { backgroundColor: pObj.color, color: pObj.textColor || '#ffffff' };

        let hash = 0;
        for (let i = 0; i < providerName.length; i++) {
            hash = providerName.charCodeAt(i) + ((hash << 5) - hash);
        }

        // Define a palette of nice colors
        const colors = [
            '#ef4444', '#f97316', '#f59e0b', '#10b981', '#06b6d4',
            '#3b82f6', '#6366f1', '#8b5cf6', '#d946ef', '#f43f5e'
        ];

        const index = Math.abs(hash) % colors.length;
        return { backgroundColor: colors[index], color: '#ffffff' };
    };

    const calculateAge = (dob: string) => {
        if (!dob) return '';
        const birthDate = new Date(dob);
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        const m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        return age;
    };

    const startResizing = (mouseDownEvent: React.MouseEvent) => {
        mouseDownEvent.preventDefault();
        setIsResizing(true);
    };

    useEffect(() => {
        const handleResize = (e: MouseEvent) => {
            // Since we are in an effect dependent on isResizing, 
            // valid checks are implicit but good to keep
            const newWidth = window.innerWidth - e.clientX;
            if (newWidth > 300 && newWidth < 800) {
                setDetailWidth(newWidth);
            }
        };

        const stopResizing = () => {
            setIsResizing(false);
        };

        if (isResizing) {
            window.addEventListener('mousemove', handleResize);
            window.addEventListener('mouseup', stopResizing);
            document.body.style.cursor = 'col-resize';
            document.body.style.userSelect = 'none';
        }

        return () => {
            window.removeEventListener('mousemove', handleResize);
            window.removeEventListener('mouseup', stopResizing);
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
        };
    }, [isResizing]);
    // Set initial 50% width on client side
    useEffect(() => {
        // Assume default sidebar width ~240px and gaps. Realistically, (window.innerWidth - sidebar) / 2 is the 50% mark.
        // A safe assumption for a 50/50 split visually is half the window width minus navigation overhead.
        setDetailWidth(Math.floor(window.innerWidth / 2) - 150);
    }, []);

    useEffect(() => {
        const savedClients = localStorage.getItem('busy_bees_clients');
        if (savedClients) {
            try {
                const parsedClients = JSON.parse(savedClients);
                setClients(parsedClients);
                if (parsedClients.length > 0) {
                    setSelectedClient(parsedClients[0]);
                } else {
                    setSelectedClient(null);
                }
            } catch (e) {
                console.error("Failed to parse saved clients", e);
            }
        }

        const savedServices = localStorage.getItem('busy_bees_services');
        if (savedServices) {
            try {
                setAvailableServices(JSON.parse(savedServices));
            } catch (e) {
                console.error("Failed to parse services", e);
            }
        }

        const savedProviders = localStorage.getItem('busy_bees_providers');
        if (savedProviders) {
            try {
                setProviders(JSON.parse(savedProviders));
            } catch (e) {
                console.error("Failed to parse providers", e);
            }
        }
    }, []);

    const handleSaveClient = (clientData: any) => {
        // Map form data to client structure
        const primaryAddress = clientData.addresses.find((a: any) => a.isPrimary) || clientData.addresses[0];
        const primaryPhone = clientData.phones.find((p: any) => p.isPrimary) || clientData.phones[0];
        const primaryEmail = clientData.emails.find((e: any) => e.isPrimary) || clientData.emails[0];

        // Construct new client object
        const newClientDataObj = {
            clientId: clientData.id || Math.floor(100000 + Math.random() * 900000).toString(),
            kidsName: `${clientData.firstName} ${clientData.lastName}`,
            guardian: clientData.guardian,
            address: primaryAddress ? primaryAddress.value : '',
            phone: primaryPhone ? primaryPhone.value : '',
            dob: clientData.dob,
            email: primaryEmail ? primaryEmail.value : '',
            teacher: clientData.teacher,
            services: clientData.services,
            assignedPrograms: clientData.assignedPrograms,
            programPercentage: '0%', // Default or calculate from somewhere
            iepMeeting: clientData.iepMeeting,
            status: clientData.status,
            // Conserve full multi-entry data for future editing
            addresses: clientData.addresses,
            phones: clientData.phones,
            emails: clientData.emails
        };

        let updatedClients;
        if (clientData.id) {
            // Edit existing
            updatedClients = clients.map(c => c.clientId === clientData.id ? { ...c, ...newClientDataObj } : c);
        } else {
            // Add new
            updatedClients = [...clients, newClientDataObj];
        }

        setClients(updatedClients);
        localStorage.setItem('busy_bees_clients', JSON.stringify(updatedClients));

        // Update/Select the client
        setSelectedClient(newClientDataObj);
        setEditingClient(null); // Reset editing state
    };

    const handleEditClient = (client: any) => {
        setEditingClient(client);
        setIsAddModalOpen(true);
        setActiveActionId(null); // Close menu
    };

    const handleDeleteClient = (clientId: string) => {
        if (confirm('Are you sure you want to delete this client?')) {
            const updatedClients = clients.filter(c => c.clientId !== clientId);
            setClients(updatedClients);
            localStorage.setItem('busy_bees_clients', JSON.stringify(updatedClients));

            if (selectedClient?.clientId === clientId) {
                setSelectedClient(null);
            }
            setActiveActionId(null);
        }
    };

    const toggleActionMenu = (e: React.MouseEvent, clientId: string) => {
        e.stopPropagation(); // Prevent row selection
        setActiveActionId(activeActionId === clientId ? null : clientId);
    };

    // Apply Advanced Filters
    let filteredClients = useDataFilter({
        data: clients,
        rules: filterRules,
        matchType
    });

    if (sortConfig !== null) {
        filteredClients = [...filteredClients].sort((a: any, b: any) => {
            const aValue = a[sortConfig.key] || '';
            const bValue = b[sortConfig.key] || '';
            if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
            if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
            return 0;
        });
    }

    return (
        <div className={styles.container}>
            {/* Toolbar - Now includes Add Client Button */}
            <div className={styles.toolbar}>
                <div className={styles.leftActions}>
                    <div className={styles.searchBox}>
                        <Search size={20} color="var(--text-secondary-light)" />
                        <input type="text" placeholder="Search clients..." className={styles.searchInput} />
                    </div>
                </div>
                <div className={styles.rightActions}>
                    <button
                        className={styles.addBtn}
                        onClick={() => setIsAddModalOpen(true)}
                    >
                        <Plus size={20} />
                        <span>Add New Client</span>
                    </button>
                    <button
                        className={styles.filterBtn}
                        onClick={() => setShowFilterDrawer(true)}
                    >
                        <Filter size={16} color="currentColor" />
                        <span>Filter {filterRules.length > 0 && `(${filterRules.length})`}</span>
                    </button>
                    <button className={styles.moreActionsBtn}>
                        <MoreVertical size={20} />
                    </button>
                </div>
            </div>

            <FilterDrawer
                isOpen={showFilterDrawer}
                onClose={() => setShowFilterDrawer(false)}
                storageKey="clients"
                columns={[
                    { id: 'clientId', label: 'Client ID' },
                    { id: 'kidsName', label: 'Child Name' },
                    { id: 'guardian', label: 'Guardian' },
                    { id: 'address', label: 'Address' },
                    { id: 'phone', label: 'Phone' },
                    { id: 'email', label: 'Email' },
                    { id: 'teacher', label: 'Teacher' }
                ]}
                rules={filterRules}
                matchType={matchType}
                onApply={(rules, matchType) => {
                    setFilterRules(rules);
                    setMatchType(matchType);
                    setShowFilterDrawer(false);
                }}
            />

            {/* Content Area - Split View */}
            <div className={styles.contentWrapper}>
                {/* Clients Table */}
                <div className={`${styles.tableWrapper} ${selectedClient ? styles.tableWrapperShrink : ''}`}>
                    <div className={styles.tableContainer}>
                        <table className={styles.table}>
                            <thead>
                                <tr>
                                    <th onClick={() => handleSort('clientId')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                            Client ID
                                            <ArrowUpDown size={14} color={sortConfig?.key === 'clientId' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                        </div>
                                    </th>
                                    <th onClick={() => handleSort('kidsName')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                            Child Name
                                            <ArrowUpDown size={14} color={sortConfig?.key === 'kidsName' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                        </div>
                                    </th>
                                    <th onClick={() => handleSort('dob')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                            Age
                                            <ArrowUpDown size={14} color={sortConfig?.key === 'dob' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                        </div>
                                    </th>
                                    <th onClick={() => handleSort('guardian')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                            Guardian
                                            <ArrowUpDown size={14} color={sortConfig?.key === 'guardian' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                        </div>
                                    </th>
                                    <th onClick={() => handleSort('status')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                            Status
                                            <ArrowUpDown size={14} color={sortConfig?.key === 'status' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                        </div>
                                    </th>
                                    {!selectedClient && (
                                        <>
                                            <th onClick={() => handleSort('address')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                                    Address
                                                    <ArrowUpDown size={14} color={sortConfig?.key === 'address' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                                </div>
                                            </th>
                                            <th onClick={() => handleSort('phone')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                                    Phone
                                                    <ArrowUpDown size={14} color={sortConfig?.key === 'phone' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                                </div>
                                            </th>
                                            <th onClick={() => handleSort('dob')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                                    Date of Birth
                                                    <ArrowUpDown size={14} color={sortConfig?.key === 'dob' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                                </div>
                                            </th>
                                            <th onClick={() => handleSort('email')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                                    Email
                                                    <ArrowUpDown size={14} color={sortConfig?.key === 'email' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                                </div>
                                            </th>
                                            <th onClick={() => handleSort('teacher')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                                    Teacher's
                                                    <ArrowUpDown size={14} color={sortConfig?.key === 'teacher' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                                </div>
                                            </th>
                                            <th>Services</th>
                                            <th onClick={() => handleSort('assignedPrograms')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                                    Assigned Programs
                                                    <ArrowUpDown size={14} color={sortConfig?.key === 'assignedPrograms' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                                </div>
                                            </th>
                                            <th onClick={() => handleSort('programPercentage')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                                    Program %
                                                    <ArrowUpDown size={14} color={sortConfig?.key === 'programPercentage' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                                </div>
                                            </th>
                                            <th onClick={() => handleSort('iepMeeting')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                                    IEP Meeting
                                                    <ArrowUpDown size={14} color={sortConfig?.key === 'iepMeeting' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                                </div>
                                            </th>
                                        </>
                                    )}
                                    <th style={{ textAlign: 'center' }}>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredClients.map((client) => (
                                    <tr
                                        key={client.clientId}
                                        className={`${selectedClient?.clientId === client.clientId ? styles.selectedRow : ''}`}
                                        onClick={() => setSelectedClient(client)}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        <td><span className={styles.cellText}>CLI-{client.clientId}</span></td>
                                        <td><span className={styles.clientName}>{client.kidsName}</span></td>
                                        <td><span className={styles.cellText}>{calculateAge(client.dob)}</span></td>
                                        <td><span className={styles.cellText}>{client.guardian}</span></td>
                                        <td>
                                            <span className={`${styles.statusBadge} ${client.status === 'Active' ? styles.active : styles.inactive}`}>
                                                {client.status}
                                            </span>
                                        </td>
                                        {!selectedClient && (
                                            <>
                                                <td><span className={styles.cellText}>{client.address}</span></td>
                                                <td><span className={styles.cellText}>{client.phone}</span></td>
                                                <td><span className={styles.cellText}>{client.dob}</span></td>
                                                <td><span className={styles.cellText}>{client.email}</span></td>
                                                <td><span className={styles.cellText}>{client.teacher}</span></td>
                                                <td>
                                                    <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                                                        {Array.isArray(client.services)
                                                            ? client.services.map((s: any, idx: number) => {
                                                                const providerName = getServiceProvider(s.serviceId);
                                                                const providerStyle = getProviderStyle(providerName);
                                                                return (
                                                                    <span
                                                                        key={idx}
                                                                        className={styles.serviceBubble}
                                                                        style={providerStyle}
                                                                        title={`Provider: ${providerName}`}
                                                                    >
                                                                        {getServiceName(s.serviceId)}
                                                                    </span>
                                                                );
                                                            })
                                                            : <span className={styles.cellText}>{client.services || 'None'}</span>}
                                                    </div>
                                                </td>
                                                <td><span className={styles.cellText}>{client.assignedPrograms}</span></td>
                                                <td><span className={styles.cellText}>{client.programPercentage}</span></td>
                                                <td><span className={styles.cellText}>{client.iepMeeting}</span></td>
                                            </>
                                        )}
                                        <td>
                                            <div className={styles.actionMenuContainer}>
                                                <button
                                                    className={styles.actionBtn}
                                                    onClick={(e) => toggleActionMenu(e, client.clientId)}
                                                >
                                                    <MoreVertical size={20} />
                                                </button>

                                                {activeActionId === client.clientId && (
                                                    <div className={styles.dropdownMenu} onClick={(e) => e.stopPropagation()}>
                                                        <button
                                                            className={styles.dropdownItem}
                                                            onClick={() => handleEditClient(client)}
                                                        >
                                                            <Pencil size={16} />
                                                            <span>Edit</span>
                                                        </button>
                                                        <button
                                                            className={`${styles.dropdownItem} ${styles.deleteItem}`}
                                                            onClick={() => handleDeleteClient(client.clientId)}
                                                        >
                                                            <Trash2 size={16} />
                                                            <span>Delete</span>
                                                        </button>
                                                    </div>
                                                )}
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        <div style={{ padding: '16px 24px', color: 'var(--text-secondary-light)', fontSize: '13px', borderTop: '1px solid var(--border-light)', backgroundColor: '#f9fafb', fontWeight: 500 }}>
                            Showing {filteredClients.length} rows
                        </div>
                    </div>
                </div>

                {/* Detail View (Right Panel) */}
                {selectedClient && (
                    <aside
                        className={styles.detailView}
                        style={{
                            width: detailWidth ? `${detailWidth}px` : '50%',
                            flexBasis: detailWidth ? `${detailWidth}px` : '50%',
                            flexShrink: 0
                        }}
                        ref={sidebarRef}
                    >
                        <div
                            className={styles.resizeHandle}
                            onMouseDown={startResizing}
                        />
                        <div className={styles.detailCard}>
                            <div className={styles.detailHeader}>
                                <div
                                    className={`${styles.detailClientId} ${selectedClient.status === 'Active' ? styles.activeClientId : styles.inactiveClientId
                                        }`}
                                >
                                    Client ID: {selectedClient.clientId}
                                </div>
                                <div className={styles.avatarLarge}>
                                    <User size={32} color="white" />
                                </div>
                                <label className={styles.detailLabel}>Child Name</label>
                                <h2 className={styles.detailName}>{selectedClient.kidsName}</h2>
                                <label className={styles.detailLabel}>Guardian Name</label>
                                <p className={styles.detailGuardian}>{selectedClient.guardian}</p>
                                <div className={styles.detailActions}>
                                    <button className={styles.iconBtn} title="Call"><Phone size={18} /></button>
                                    <button className={styles.iconBtn} title="Email"><Mail size={18} /></button>
                                    <button className={styles.iconBtn} title="Events"><Calendar size={18} /></button>
                                </div>
                            </div>

                            <div className={styles.detailBody}>
                                {/* Contact Information Section */}
                                <div className={styles.detailSection}>
                                    <h3 className={styles.sectionTitle}>Contact Information</h3>
                                    <div className={styles.infoGrid}>
                                        <div className={styles.infoItem}>
                                            <label>Email</label>
                                            {(selectedClient as any).emails && Array.isArray((selectedClient as any).emails) ? (
                                                <div className={styles.multiEntryList}>
                                                    {[...(selectedClient as any).emails]
                                                        .sort((a: any, b: any) => (b.isPrimary ? 1 : 0) - (a.isPrimary ? 1 : 0))
                                                        .map((email: any) => (
                                                            <div key={email.id} className={styles.multiEntryItem}>
                                                                <div className={styles.multiEntryLeft}>
                                                                    {email.isPrimary ? <span className={styles.primaryBadge}>P</span> : <span />}
                                                                    <span className={styles.multiEntryValue}>{email.value}</span>
                                                                </div>
                                                                <span className={styles.multiEntryType}>{email.type}</span>
                                                            </div>
                                                        ))}
                                                </div>
                                            ) : (
                                                <span>{selectedClient.email}</span>
                                            )}
                                        </div>
                                        <div className={styles.infoItem}>
                                            <label>Phone</label>
                                            {(selectedClient as any).phones && Array.isArray((selectedClient as any).phones) ? (
                                                <div className={styles.multiEntryList}>
                                                    {[...(selectedClient as any).phones]
                                                        .sort((a: any, b: any) => (b.isPrimary ? 1 : 0) - (a.isPrimary ? 1 : 0))
                                                        .map((phone: any) => (
                                                            <div key={phone.id} className={styles.multiEntryItem}>
                                                                <div className={styles.multiEntryLeft}>
                                                                    {phone.isPrimary ? <span className={styles.primaryBadge}>P</span> : <span />}
                                                                    <span className={styles.multiEntryValue}>{phone.value}</span>
                                                                </div>
                                                                <span className={styles.multiEntryType}>{phone.type}</span>
                                                            </div>
                                                        ))}
                                                </div>
                                            ) : (
                                                <span>{selectedClient.phone}</span>
                                            )}
                                        </div>
                                        <div className={styles.infoItem}>
                                            <label>Address</label>
                                            {(selectedClient as any).addresses && Array.isArray((selectedClient as any).addresses) ? (
                                                <div className={styles.multiEntryList}>
                                                    {[...(selectedClient as any).addresses]
                                                        .sort((a: any, b: any) => (b.isPrimary ? 1 : 0) - (a.isPrimary ? 1 : 0))
                                                        .map((address: any) => (
                                                            <div key={address.id} className={styles.multiEntryItem}>
                                                                <div className={styles.multiEntryLeft}>
                                                                    {address.isPrimary ? <span className={styles.primaryBadge}>P</span> : <span />}
                                                                    <span className={styles.multiEntryValue}>{address.value}</span>
                                                                </div>
                                                                <span className={styles.multiEntryType}>{address.type}</span>
                                                            </div>
                                                        ))}
                                                </div>
                                            ) : (
                                                <span>{selectedClient.address}</span>
                                            )}
                                        </div>
                                    </div>
                                </div>

                                <div className={styles.divider} />

                                {/* Personal Details Section */}
                                <div className={styles.detailSection}>
                                    <h3 className={styles.sectionTitle}>Personal Details</h3>
                                    <div className={styles.infoGridTwoCol}>
                                        <div className={styles.infoItem}>
                                            <label>Date of Birth</label>
                                            <span>{selectedClient.dob}</span>
                                        </div>
                                        <div className={styles.infoItem}>
                                            <label>Age</label>
                                            <span>{calculateAge(selectedClient.dob)}</span>
                                        </div>
                                    </div>
                                </div>

                                <div className={styles.divider} />

                                {/* Education & Services Section */}
                                <div className={styles.detailSection}>
                                    <h3 className={styles.sectionTitle}>Education & Services</h3>
                                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '16px' }}>
                                        <div className={styles.infoItem}>
                                            <label>Teacher</label>
                                            <span>{selectedClient.teacher}</span>
                                        </div>
                                        <div className={styles.infoItem}>
                                            <label>IEP Meeting</label>
                                            <span>{selectedClient.iepMeeting}</span>
                                        </div>
                                        <div className={styles.infoItem}>
                                            <label>Assigned Programs</label>
                                            <span>{selectedClient.assignedPrograms}</span>
                                        </div>
                                        <div className={styles.infoItem}>
                                            <label>Program %</label>
                                            <span>{selectedClient.programPercentage}</span>
                                        </div>
                                    </div>
                                    <div className={styles.infoGrid}>
                                        <div className={styles.infoItem} style={{ gridColumn: '1 / -1' }}>
                                            <label>Services</label>
                                            {Array.isArray(selectedClient.services) && selectedClient.services.length > 0 ? (
                                                <table className={styles.detailServicesTable}>
                                                    <thead>
                                                        <tr>
                                                            <th>Service Provider</th>
                                                            <th>Service Name</th>
                                                            <th>Hours</th>
                                                            <th>Used</th>
                                                            <th>Remaining</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {(selectedClient.services as any[]).map((srv, idx) => {
                                                            const providerName = getServiceProvider(srv.serviceId);
                                                            const providerStyle = getProviderStyle(providerName);
                                                            const color = providerStyle.backgroundColor;

                                                            return (
                                                                <tr key={idx} style={{ backgroundColor: color }}>
                                                                    <td style={{ color: providerStyle.color }}>
                                                                        <span style={{ fontWeight: 600, color: providerStyle.color }}>
                                                                            {providerName}
                                                                        </span>
                                                                    </td>
                                                                    <td style={{ fontWeight: 500, color: providerStyle.color }}>{getServiceName(srv.serviceId)}</td>
                                                                    <td style={{ color: providerStyle.color }}>
                                                                        <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                                                            <Clock size={14} color={providerStyle.color} />
                                                                            {srv.hours}
                                                                        </span>
                                                                    </td>
                                                                    <td style={{ color: providerStyle.color }}>0h</td>
                                                                    <td style={{ fontWeight: 600, color: providerStyle.color }}>{srv.hours}</td>
                                                                </tr>
                                                            );
                                                        })}
                                                    </tbody>
                                                </table>
                                            ) : (
                                                <span style={{ fontSize: '14px', color: 'var(--text-secondary-light)' }}>
                                                    {selectedClient.services || 'None Assigned'}
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <button className={styles.closeBtn} onClick={() => setSelectedClient(null)}>
                                <X size={20} />
                            </button>
                        </div>
                    </aside>
                )}
            </div>

            <AddClientModal
                isOpen={isAddModalOpen}
                onClose={() => {
                    setIsAddModalOpen(false);
                    setEditingClient(null); // Reset when closing
                }}
                onSave={handleSaveClient}
                initialData={editingClient}
            />
        </div>
    );
}
