'use client';

import { useState, useMemo } from 'react';
import { Search, Plus, MoreHorizontal, ArrowUpDown, Filter, Pencil, Trash2 } from 'lucide-react';
import styles from './page.module.css';
import FilterDrawer from '@/components/ui/FilterDrawer';
import { useDataFilter, FilterRule, MatchType } from '@/hooks/useDataFilter';

const MOCK_BASELINE_DATA = [
    {
        id: 1,
        clientId: 'CLI-930291',
        clientName: 'Oliver Smith',
        employeeId: 'EMP-001',
        employeeName: 'Sarah Jenkins',
        program: 'Math Readiness',
        sto: 'Number Recognition 1-10',
        date: '2024-10-24',
        status: 'Success'
    },
    {
        id: 2,
        clientId: 'CLI-482019',
        clientName: 'Noah Wilson',
        employeeId: 'EMP-002',
        employeeName: 'Michael Brown',
        program: 'Reading Comprehension',
        sto: 'Identify Main Character',
        date: '2024-10-25',
        status: 'Failed'
    },
    {
        id: 3,
        clientId: 'CLI-593810',
        clientName: 'Liam Martinez',
        employeeId: 'EMP-001',
        employeeName: 'Sarah Jenkins',
        program: 'Writing',
        sto: 'Tracing First Name',
        date: '2024-10-26',
        status: 'Success'
    }
];

export default function AcademicBaselinePage() {
    // Filter State
    const [searchQuery, setSearchQuery] = useState('');
    const [showFilterDrawer, setShowFilterDrawer] = useState(false);
    const [filterRules, setFilterRules] = useState<FilterRule[]>([]);
    const [matchType, setMatchType] = useState<MatchType>('AND');

    // Sorting State
    const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' } | null>(null);

    // Apply Filters
    const filteredByRules = useDataFilter({ data: MOCK_BASELINE_DATA, rules: filterRules, matchType });

    // Apply Search
    const filteredData = useMemo(() => {
        return filteredByRules.filter(item => {
            const matchesSearch = Object.values(item).some(val =>
                String(val).toLowerCase().includes(searchQuery.toLowerCase())
            );
            return matchesSearch;
        });
    }, [filteredByRules, searchQuery]);

    const handleSort = (key: string) => {
        let direction: 'asc' | 'desc' = 'asc';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    // Apply Sorting
    const sortedData = useMemo(() => {
        if (!sortConfig) return filteredData;
        return [...filteredData].sort((a: any, b: any) => {
            const aValue = a[sortConfig.key] || '';
            const bValue = b[sortConfig.key] || '';
            if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
            if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
            return 0;
        });
    }, [filteredData, sortConfig]);

    return (
        <div className={styles.container}>
            {/* Toolbar */}
            <div className={styles.toolbar} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
                <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                    <div className={styles.searchBox}>
                        <Search size={20} color="var(--text-secondary-light)" />
                        <input
                            type="text"
                            placeholder="Search entries..."
                            className={styles.searchInput}
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>
                </div>

                <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                    <button className={styles.addBtn}>
                        <Plus size={20} />
                        <span>Add Academic Baseline</span>
                    </button>

                    <button
                        className={styles.filterBtn}
                        onClick={() => setShowFilterDrawer(true)}
                    >
                        <Filter size={16} color="currentColor" />
                        <span>Filter {filterRules.length > 0 && `(${filterRules.length})`}</span>
                    </button>
                </div>
            </div>

            {/* Filter Drawer Panel */}
            <FilterDrawer
                isOpen={showFilterDrawer}
                onClose={() => setShowFilterDrawer(false)}
                storageKey="academic_baseline"
                columns={[
                    { id: 'clientId', label: 'Client ID' },
                    { id: 'clientName', label: 'Client Name' },
                    { id: 'employeeId', label: 'Employee ID' },
                    { id: 'employeeName', label: 'Employee Name' },
                    { id: 'program', label: 'Program' },
                    { id: 'sto', label: 'STO' },
                    { id: 'date', label: 'Date' },
                    { id: 'status', label: 'Status' }
                ]}
                rules={filterRules}
                matchType={matchType}
                onApply={(rules, type) => {
                    setFilterRules(rules);
                    setMatchType(type);
                    setShowFilterDrawer(false);
                }}
            />

            {/* Data Table */}
            <div className={styles.tableContainer}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th onClick={() => handleSort('clientId')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    Client ID
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'clientId' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th onClick={() => handleSort('clientName')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    Client Name
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'clientName' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th onClick={() => handleSort('employeeId')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    Employee ID
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'employeeId' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th onClick={() => handleSort('employeeName')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    Employee Name
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'employeeName' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th onClick={() => handleSort('program')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    Program
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'program' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th onClick={() => handleSort('sto')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    STO
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'sto' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th onClick={() => handleSort('date')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    Date
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'date' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th onClick={() => handleSort('status')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    Status
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'status' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th style={{ width: '80px', textAlign: 'center' }}>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {sortedData.map((row) => (
                            <tr key={row.id}>
                                <td><span style={{ fontWeight: 600 }}>{row.clientId}</span></td>
                                <td>{row.clientName}</td>
                                <td>{row.employeeId}</td>
                                <td>{row.employeeName}</td>
                                <td>{row.program}</td>
                                <td>{row.sto}</td>
                                <td>{row.date}</td>
                                <td>
                                    <span className={`${styles.statusBadge} ${row.status === 'Success' ? styles.success : styles.failed}`}>
                                        {row.status}
                                    </span>
                                </td>
                                <td>
                                    <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                                        <button className={styles.actionBtn} title="Edit">
                                            <Pencil size={18} />
                                        </button>
                                        <button className={styles.actionBtn} style={{ color: 'var(--error)' }} title="Delete">
                                            <Trash2 size={18} />
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                <div style={{ padding: '16px 24px', color: 'var(--text-secondary-light)', fontSize: '13px', borderTop: '1px solid var(--border-light)', backgroundColor: '#f9fafb', fontWeight: 500 }}>
                    Showing {sortedData.length} rows
                </div>
            </div>
        </div>
    );
}
