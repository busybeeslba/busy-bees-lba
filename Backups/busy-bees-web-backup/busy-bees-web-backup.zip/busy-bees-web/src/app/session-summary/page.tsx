'use client';

import { useState, useMemo } from 'react';
import { Search, MoreHorizontal, Calendar, Clock, User, Building2, ArrowUpDown } from 'lucide-react';
import styles from './page.module.css';

const MOCK_SESSIONS = [
    { id: 'S-1001', date: 'Oct 24, 2025', time: '09:00 AM', employee: 'Sarah Connor', client: 'Acme Corp', service: 'Standard Maintenance', duration: '2h 15m', status: 'Completed' },
    { id: 'S-1002', date: 'Oct 24, 2025', time: '11:45 AM', employee: 'Kyle Reese', client: 'Westside Library', service: 'Basic Consultation', duration: '1h 00m', status: 'Completed' },
    { id: 'S-1003', date: 'Oct 24, 2025', time: '02:30 PM', employee: 'John Doe', client: 'Downtown Cafe', service: 'Emergency Repair', duration: '45m', status: 'Pending Verification' },
    { id: 'S-1004', date: 'Oct 23, 2025', time: '10:00 AM', employee: 'Sarah Connor', client: 'John Smith Residence', service: 'Full Installation', duration: '5h 30m', status: 'Completed' },
];

export default function SessionSummaryPage() {
    const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' } | null>(null);

    const handleSort = (key: string) => {
        let direction: 'asc' | 'desc' = 'asc';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    const sortedSessions = useMemo(() => {
        let sortableItems = [...MOCK_SESSIONS];
        if (sortConfig !== null) {
            sortableItems.sort((a: any, b: any) => {
                const aValue = a[sortConfig.key] || '';
                const bValue = b[sortConfig.key] || '';
                if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
                if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
                return 0;
            });
        }
        return sortableItems;
    }, [sortConfig]);

    return (
        <div className={styles.container}>
            <header className={styles.header}>
                <div>
                    <h1 className={styles.title}>Session Summary</h1>
                    <p className={styles.subtitle}>Review logs of completed field operations.</p>
                </div>
            </header>

            {/* Toolbar */}
            <div className={styles.toolbar}>
                <div className={styles.searchBox}>
                    <Search size={20} color="var(--text-secondary-light)" />
                    <input type="text" placeholder="Search sessions..." className={styles.searchInput} />
                </div>
                <div className={styles.filters}>
                    <select className={styles.select}>
                        <option>All Dates</option>
                        <option>Today</option>
                        <option>This Week</option>
                        <option>This Month</option>
                    </select>
                    <select className={styles.select}>
                        <option>All Status</option>
                        <option>Completed</option>
                        <option>Pending</option>
                    </select>
                </div>
            </div>

            {/* Sessions Table */}
            <div className={styles.tableContainer}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th onClick={() => handleSort('date')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    Date & Time
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'date' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th onClick={() => handleSort('employee')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    Employee
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'employee' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th onClick={() => handleSort('client')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    Client
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'client' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th onClick={() => handleSort('service')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    Service
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'service' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th onClick={() => handleSort('duration')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    Duration
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'duration' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th onClick={() => handleSort('status')} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    Status
                                    <ArrowUpDown size={14} color={sortConfig?.key === 'status' ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                </div>
                            </th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        {sortedSessions.map((session) => (
                            <tr key={session.id}>
                                <td>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                        <Calendar size={14} color="var(--text-secondary-light)" />
                                        <div>
                                            <span className={styles.sessionDate}>{session.date}</span>
                                            <span className={styles.sessionTime}>{session.time}</span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                        <User size={14} color="var(--text-secondary-light)" />
                                        <span>{session.employee}</span>
                                    </div>
                                </td>
                                <td>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                        <Building2 size={14} color="var(--text-secondary-light)" />
                                        <span className={styles.clientName}>{session.client}</span>
                                    </div>
                                </td>
                                <td>{session.service}</td>
                                <td>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                        <Clock size={14} color="var(--text-secondary-light)" />
                                        {session.duration}
                                    </div>
                                </td>
                                <td>
                                    <span className={`${styles.statusBadge} ${session.status === 'Completed' ? styles.completed : styles.pending
                                        }`}>
                                        {session.status}
                                    </span>
                                </td>
                                <td>
                                    <button className={styles.actionBtn}>
                                        <MoreHorizontal size={20} />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                <div style={{ padding: '16px 24px', color: 'var(--text-secondary-light)', fontSize: '13px', borderTop: '1px solid var(--border-light)', backgroundColor: '#f9fafb', fontWeight: 500 }}>
                    Showing {sortedSessions.length} rows
                </div>
            </div>
        </div>
    );
}
