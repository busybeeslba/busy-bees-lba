export const MOCK_AVAILABLE_SERVICES = [
    { serviceId: 'SRV-1001', name: 'ABA Therapy' },
    { serviceId: 'SRV-1002', name: 'Speech Therapy' },
    { serviceId: 'SRV-1003', name: 'Occupational Therapy' },
    { serviceId: 'SRV-1004', name: 'Social Skills Group' },
];
