'use client';

import { useState, useEffect, useRef } from 'react';
import { X, Plus, Trash2, Check } from 'lucide-react';
import styles from './AddClientModal.module.css';
import { MOCK_AVAILABLE_SERVICES } from '@/lib/mockData';

interface MultiEntry {
    id: string;
    value: string;
    type: string;
    isPrimary: boolean;
}

interface ServiceEntry {
    id: string;
    serviceId: string;
    hours: string;
}

interface AddClientModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (data: any) => void;
    initialData?: any; // Add initialData prop
}

const ADDRESS_TYPES = ['Home', 'School', 'Work', 'Other'];
const PHONE_TYPES = ['Mobile', 'Home', 'Work', 'Emergency'];
const EMAIL_TYPES = ['Personal', 'Work', 'School', 'Other'];

// Address Input Component with Photon Autocomplete
const AddressInput = ({
    value,
    onChange,
    placeholder,
    className
}: {
    value: string;
    onChange: (val: string) => void;
    placeholder: string;
    className: string;
}) => {
    const [suggestions, setSuggestions] = useState<any[]>([]);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const wrapperRef = useRef<HTMLDivElement>(null);

    // Debounce search
    useEffect(() => {
        const timer = setTimeout(() => {
            if (value && value.length > 2 && showSuggestions) {
                const apiKey = process.env.NEXT_PUBLIC_GEOAPIFY_API_KEY;
                if (!apiKey) {
                    console.warn("Geoapify API Key is missing");
                    return;
                }

                fetch(`https://api.geoapify.com/v1/geocode/autocomplete?text=${encodeURIComponent(value)}&apiKey=${apiKey}&limit=5&filter=countrycode:us`)
                    .then(res => res.json())
                    .then(data => {
                        setSuggestions(data.features || []);
                    })
                    .catch(err => console.error("Geoapify API Error:", err));
            } else if (!value) {
                setSuggestions([]);
            }
        }, 300);

        return () => clearTimeout(timer);
    }, [value, showSuggestions]);

    // Handle outside click
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setShowSuggestions(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleSelect = (feature: any) => {
        const props = feature.properties;
        const formattedAddress = props.formatted;
        onChange(formattedAddress);
        setShowSuggestions(false);
    };

    return (
        <div className={styles.addressWrapper} ref={wrapperRef}>
            <input
                type="text"
                className={className}
                placeholder={placeholder}
                value={value}
                onChange={(e) => {
                    onChange(e.target.value);
                    setShowSuggestions(true);
                }}
                onFocus={() => setShowSuggestions(true)}
                style={{ width: '100%' }}
            />
            {showSuggestions && suggestions.length > 0 && (
                <ul className={styles.suggestionsList}>
                    {suggestions.map((suggestion, index) => {
                        const props = suggestion.properties;
                        return (
                            <li
                                key={index}
                                className={styles.suggestionItem}
                                onClick={() => handleSelect(suggestion)}
                            >
                                {props.formatted}
                            </li>
                        );
                    })}
                </ul>
            )}
        </div>
    );
};

export default function AddClientModal({ isOpen, onClose, onSave, initialData }: AddClientModalProps) {
    // Basic Info
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [guardian, setGuardian] = useState('');
    const [dob, setDob] = useState('');
    const [status, setStatus] = useState('Active');

    // Additional Fields
    const [teacher, setTeacher] = useState('');
    const [clientServices, setClientServices] = useState<ServiceEntry[]>([
        { id: '1', serviceId: '', hours: '0h' }
    ]);
    const [assignedPrograms, setAssignedPrograms] = useState('');
    const [iepMeeting, setIepMeeting] = useState('');
    const [availableServices, setAvailableServices] = useState<any[]>([]);

    useEffect(() => {
        const savedServices = localStorage.getItem('busy_bees_services');
        if (savedServices) {
            try {
                setAvailableServices(JSON.parse(savedServices));
            } catch (e) {
                console.error("Failed to parse available services", e);
                setAvailableServices(MOCK_AVAILABLE_SERVICES);
            }
        } else {
            setAvailableServices(MOCK_AVAILABLE_SERVICES);
        }
    }, [isOpen]);

    // Multi-entry Arrays
    const [addresses, setAddresses] = useState<MultiEntry[]>([
        { id: '1', value: '', type: 'Home', isPrimary: true }
    ]);
    const [phones, setPhones] = useState<MultiEntry[]>([
        { id: '1', value: '', type: 'Mobile', isPrimary: true }
    ]);
    const [emails, setEmails] = useState<MultiEntry[]>([
        { id: '1', value: '', type: 'Personal', isPrimary: true }
    ]);

    // Effect to populate form when initialData changes or modal opens
    useEffect(() => {
        if (isOpen && initialData) {
            // Split name if needed (simple assumption: First Last)
            const nameParts = (initialData.kidsName || '').split(' ');
            setFirstName(nameParts[0] || '');
            setLastName(nameParts.slice(1).join(' ') || '');

            setGuardian(initialData.guardian || '');
            setDob(initialData.dob || '');
            setStatus(initialData.status || 'Active');
            setTeacher(initialData.teacher || '');
            if (initialData.services && Array.isArray(initialData.services)) {
                setClientServices(initialData.services.length > 0 ? initialData.services : [{ id: '1', serviceId: '', hours: '0h' }]);
            } else if (initialData.services && typeof initialData.services === 'string') {
                // Fallback for old string format based on name lookup
                // Complex resolution omitted for brevity, fallback to empty selection
                setClientServices([{ id: '1', serviceId: '', hours: '0h' }]);
            } else {
                setClientServices([{ id: '1', serviceId: '', hours: '0h' }]);
            }
            setAssignedPrograms(initialData.assignedPrograms || '');
            setIepMeeting(initialData.iepMeeting || '');

            // Handle multi-entry fields if they exist in initialData, 
            // otherwise parse from flattened string or default
            // checks if initialData has array, else creates default from string 
            // (Assumes persistence saves array structure, if not, we fallback to parsing or default)
            if (initialData.phones && Array.isArray(initialData.phones)) {
                setPhones(initialData.phones);
            } else if (initialData.phone) {
                setPhones([{ id: Date.now().toString(), value: initialData.phone, type: 'Mobile', isPrimary: true }]);
            } else {
                setPhones([{ id: '1', value: '', type: 'Mobile', isPrimary: true }]);
            }

            if (initialData.emails && Array.isArray(initialData.emails)) {
                setEmails(initialData.emails);
            } else if (initialData.email) {
                setEmails([{ id: Date.now().toString() + '1', value: initialData.email, type: 'Personal', isPrimary: true }]);
            } else {
                setEmails([{ id: '1', value: '', type: 'Personal', isPrimary: true }]);
            }

            if (initialData.addresses && Array.isArray(initialData.addresses)) {
                setAddresses(initialData.addresses);
            } else if (initialData.address) {
                setAddresses([{ id: Date.now().toString() + '2', value: initialData.address, type: 'Home', isPrimary: true }]);
            } else {
                setAddresses([{ id: '1', value: '', type: 'Home', isPrimary: true }]);
            }

        } else if (isOpen && !initialData) {
            // Reset form for "Add New"
            setFirstName('');
            setLastName('');
            setGuardian('');
            setDob('');
            setStatus('Active');
            setTeacher('');
            setClientServices([{ id: '1', serviceId: '', hours: '0h' }]);
            setAssignedPrograms('');
            setIepMeeting('');
            setAddresses([{ id: '1', value: '', type: 'Home', isPrimary: true }]);
            setPhones([{ id: '1', value: '', type: 'Mobile', isPrimary: true }]);
            setEmails([{ id: '1', value: '', type: 'Personal', isPrimary: true }]);
        }
    }, [isOpen, initialData]);

    // Helpers
    const capitalizeWords = (str: string) => {
        return str.replace(/\b\w/g, l => l.toUpperCase());
    };

    const handleNameChange = (setter: (val: string) => void, value: string) => {
        setter(capitalizeWords(value));
    };

    const formatPhoneNumber = (value: string) => {
        if (!value) return value;
        const phoneNumber = value.replace(/[^\d]/g, '');
        const phoneNumberLength = phoneNumber.length;
        if (phoneNumberLength < 4) return phoneNumber;
        if (phoneNumberLength < 7) {
            return `${phoneNumber.slice(0, 3)}-${phoneNumber.slice(3)}`;
        }
        return `${phoneNumber.slice(0, 3)}-${phoneNumber.slice(3, 6)}-${phoneNumber.slice(6, 10)}`;
    };

    if (!isOpen) return null;

    // Helper functions for multi-entry fields
    const updateEntry = (
        setFunc: React.Dispatch<React.SetStateAction<MultiEntry[]>>,
        id: string,
        field: keyof MultiEntry,
        value: any
    ) => {
        setFunc(prev => prev.map(entry =>
            entry.id === id ? { ...entry, [field]: value } : entry
        ));
    };

    const setPrimary = (
        setFunc: React.Dispatch<React.SetStateAction<MultiEntry[]>>,
        id: string
    ) => {
        setFunc(prev => prev.map(entry => ({
            ...entry,
            isPrimary: entry.id === id
        })));
    };

    const addEntry = (
        setFunc: React.Dispatch<React.SetStateAction<MultiEntry[]>>,
        defaultType: string
    ) => {
        setFunc(prev => [
            ...prev,
            { id: Date.now().toString(), value: '', type: defaultType, isPrimary: false }
        ]);
    };

    const removeEntry = (
        setFunc: React.Dispatch<React.SetStateAction<MultiEntry[]>>,
        id: string
    ) => {
        setFunc(prev => {
            const newValue = prev.filter(entry => entry.id !== id);
            // If we removed the primary, make the first one primary
            if (prev.find(e => e.id === id)?.isPrimary && newValue.length > 0) {
                newValue[0].isPrimary = true;
            }
            return newValue;
        });
    };

    const updateServiceEntry = (id: string, field: keyof ServiceEntry, value: string) => {
        setClientServices(prev => prev.map(entry =>
            entry.id === id ? { ...entry, [field]: value } : entry
        ));
    };

    const addServiceEntry = () => {
        setClientServices(prev => [
            ...prev,
            { id: Date.now().toString(), serviceId: '', hours: '0h' }
        ]);
    };

    const removeServiceEntry = (id: string) => {
        setClientServices(prev => prev.filter(entry => entry.id !== id));
    };

    const renderMultiEntryField = (
        label: string,
        entries: MultiEntry[],
        setEntries: React.Dispatch<React.SetStateAction<MultiEntry[]>>,
        types: string[],
        placeholder: string
    ) => (
        <div className={styles.formGroup}>
            <label className={styles.label}>{label}</label>
            <div className={styles.multiEntryGroup}>
                {entries.map((entry) => (
                    <div key={entry.id} className={styles.entryRow}>
                        {label === 'Addresses' ? (
                            <AddressInput
                                value={entry.value}
                                onChange={(val) => updateEntry(setEntries, entry.id, 'value', val)}
                                placeholder={placeholder}
                                className={styles.input}
                            />
                        ) : (
                            <input
                                type="text"
                                className={styles.input}
                                placeholder={placeholder}
                                value={entry.value}
                                onChange={(e) => {
                                    let val = e.target.value;
                                    if (label === 'Phone Numbers') {
                                        val = formatPhoneNumber(val);
                                    }
                                    updateEntry(setEntries, entry.id, 'value', val);
                                }}
                                style={{ flex: 1 }}
                            />
                        )}

                        <div className={styles.entryControls}>
                            <select
                                className={styles.select}
                                style={{ width: '110px' }}
                                value={entry.type}
                                onChange={(e) => updateEntry(setEntries, entry.id, 'type', e.target.value)}
                            >
                                {types.map(t => <option key={t} value={t}>{t}</option>)}
                            </select>

                            <button
                                className={`${styles.primaryToggle} ${entry.isPrimary ? styles.active : ''}`}
                                onClick={() => setPrimary(setEntries, entry.id)}
                                title={entry.isPrimary ? "Primary Contact" : "Set as Primary"}
                            >
                                {entry.isPrimary && <Check size={14} strokeWidth={3} />}
                            </button>

                            {entries.length > 1 && (
                                <button
                                    className={styles.removeBtn}
                                    onClick={() => removeEntry(setEntries, entry.id)}
                                >
                                    <Trash2 size={16} />
                                </button>
                            )}
                        </div>
                    </div>
                ))}
                <button
                    className={styles.addEntryBtn}
                    onClick={() => addEntry(setEntries, types[0])}
                >
                    <Plus size={14} /> Add {label}
                </button>
            </div>
        </div>
    );

    const renderServiceEntries = () => (
        <div className={`${styles.formGroup} ${styles.fullWidth}`}>
            <label className={styles.label}>Assigned Services</label>
            <div className={styles.multiEntryGroup}>
                {clientServices.map((entry) => (
                    <div key={entry.id} className={styles.entryRow}>
                        <select
                            className={styles.select}
                            style={{ flex: 2 }}
                            value={entry.serviceId}
                            onChange={(e) => updateServiceEntry(entry.id, 'serviceId', e.target.value)}
                        >
                            <option value="">Select a service...</option>
                            {availableServices.map(srv => (
                                <option key={srv.serviceId} value={srv.serviceId}>
                                    {srv.name} ({srv.provider || 'Unassigned'})
                                </option>
                            ))}
                        </select>
                        <input
                            type="text"
                            className={styles.input}
                            placeholder="e.g. 12h"
                            value={entry.hours}
                            onChange={(e) => updateServiceEntry(entry.id, 'hours', e.target.value)}
                            style={{ flex: 1, minWidth: '80px' }}
                        />
                        <div className={styles.entryControls}>
                            {clientServices.length > 1 && (
                                <button
                                    className={styles.removeBtn}
                                    onClick={() => removeServiceEntry(entry.id)}
                                >
                                    <Trash2 size={16} />
                                </button>
                            )}
                        </div>
                    </div>
                ))}
                <button
                    className={styles.addEntryBtn}
                    onClick={addServiceEntry}
                    type="button"
                >
                    <Plus size={14} /> Add Service
                </button>
            </div>
        </div>
    );

    const handleSave = () => {
        const clientData = {
            id: initialData?.clientId, // Pass ID if editing
            firstName,
            lastName,
            guardian,
            dob,
            status,
            teacher,
            services: clientServices.filter(s => s.serviceId.trim() !== ''), // Pass structured array filtering empties
            assignedPrograms,
            iepMeeting,
            addresses,
            phones,
            emails
        };
        onSave(clientData);
        onClose();
    };

    return (
        <div className={styles.overlay}>
            <div className={styles.modal}>
                <div className={styles.header}>
                    <h2>{initialData ? 'Edit Client' : 'Add New Client'}</h2>
                    <button className={styles.closeBtn} onClick={onClose}>
                        <X size={24} />
                    </button>
                </div>

                <div className={styles.content}>
                    {/* Basic Information */}
                    <div className={styles.formSection}>
                        <h3 className={styles.sectionTitle}>Basic Information</h3>
                        <div className={styles.formGrid}>
                            <div className={styles.formGroup}>
                                <label className={styles.label}>First Name</label>
                                <input
                                    type="text"
                                    className={styles.input}
                                    value={firstName}
                                    onChange={(e) => handleNameChange(setFirstName, e.target.value)}
                                />
                            </div>
                            <div className={styles.formGroup}>
                                <label className={styles.label}>Last Name</label>
                                <input
                                    type="text"
                                    className={styles.input}
                                    value={lastName}
                                    onChange={(e) => handleNameChange(setLastName, e.target.value)}
                                />
                            </div>
                            <div className={styles.formGroup}>
                                <label className={styles.label}>Guardian Name</label>
                                <input
                                    type="text"
                                    className={styles.input}
                                    value={guardian}
                                    onChange={(e) => handleNameChange(setGuardian, e.target.value)}
                                />
                            </div>
                            <div className={styles.formGroup}>
                                <label className={styles.label}>Date of Birth</label>
                                <input
                                    type="date"
                                    className={styles.input}
                                    value={dob}
                                    onChange={(e) => setDob(e.target.value)}
                                />
                            </div>
                            <div className={styles.formGroup}>
                                <label className={styles.label}>Status</label>
                                <select
                                    className={styles.select}
                                    value={status}
                                    onChange={(e) => setStatus(e.target.value)}
                                >
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                    <option value="Pending">Pending</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    {/* Education & Services Information */}
                    <div className={styles.formSection}>
                        <h3 className={styles.sectionTitle}>Education & Services</h3>
                        <div className={styles.formGrid}>
                            <div className={styles.formGroup}>
                                <label className={styles.label}>Teacher's Name</label>
                                <input
                                    type="text"
                                    className={styles.input}
                                    value={teacher}
                                    onChange={(e) => handleNameChange(setTeacher, e.target.value)}
                                />
                            </div>
                            <div className={styles.formGroup}>
                                <label className={styles.label}>IEP Meeting Date</label>
                                <input
                                    type="date"
                                    className={styles.input}
                                    value={iepMeeting}
                                    onChange={(e) => setIepMeeting(e.target.value)}
                                />
                            </div>
                            {renderServiceEntries()}
                            <div className={`${styles.formGroup} ${styles.fullWidth}`}>
                                <label className={styles.label}>Assigned Programs</label>
                                <textarea
                                    className={styles.textarea}
                                    rows={3}
                                    value={assignedPrograms}
                                    onChange={(e) => setAssignedPrograms(e.target.value)}
                                />
                            </div>
                        </div>
                    </div>

                    {/* Contact Information */}
                    <div className={styles.formSection}>
                        <h3 className={styles.sectionTitle}>Contact Information</h3>
                        <div className={styles.multiEntryGroup} style={{ gap: '24px' }}>
                            {renderMultiEntryField('Phone Numbers', phones, setPhones, PHONE_TYPES, '555-0123')}
                            {renderMultiEntryField('Email Addresses', emails, setEmails, EMAIL_TYPES, 'user@example.com')}
                            {renderMultiEntryField('Addresses', addresses, setAddresses, ADDRESS_TYPES, '123 Main St, City, State 12345')}
                        </div>
                    </div>
                </div>

                <div className={styles.footer}>
                    <button className={styles.cancelBtn} onClick={onClose}>Cancel</button>
                    <button className={styles.saveBtn} onClick={handleSave}>{initialData ? 'Save Changes' : 'Create Client'}</button>
                </div>
            </div>
        </div>
    );
}
