'use client';

import { useState, useEffect, useMemo } from 'react';
import { Search, Plus, ArrowUpDown, Filter, Pencil, Trash2, X } from 'lucide-react';
import styles from './page.module.css';
import FilterDrawer from '@/components/ui/FilterDrawer';
import { useDataFilter, FilterRule, MatchType } from '@/hooks/useDataFilter';

const DB_URL = 'http://localhost:3001';

const EMPTY_FORM = {
    clientId: '',
    clientName: '',
    employeeId: '',
    employeeName: '',
    program: '',
    sto: '',
    date: '',
    status: 'Success',
};

export default function AcademicBaselinePage() {
    const [entries, setEntries] = useState<any[]>([]);
    const [clients, setClients] = useState<any[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingEntry, setEditingEntry] = useState<any | null>(null);
    const [form, setForm] = useState({ ...EMPTY_FORM });
    const [saving, setSaving] = useState(false);

    // Filter / Sort state
    const [searchQuery, setSearchQuery] = useState('');
    const [showFilterDrawer, setShowFilterDrawer] = useState(false);
    const [filterRules, setFilterRules] = useState<FilterRule[]>([]);
    const [matchType, setMatchType] = useState<MatchType>('AND');
    const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);

    // ── Fetch data ────────────────────────────────────────────────
    useEffect(() => {
        fetch(`${DB_URL}/academic_baselines`)
            .then(r => r.json())
            .then(setEntries)
            .catch(() => setEntries([]));

        fetch(`${DB_URL}/clients`)
            .then(r => r.json())
            .then(setClients)
            .catch(() => setClients([]));
    }, []);

    // ── Open modal helpers ────────────────────────────────────────
    const openAdd = () => {
        setEditingEntry(null);
        setForm({ ...EMPTY_FORM });
        setIsModalOpen(true);
    };

    const openEdit = (row: any) => {
        setEditingEntry(row);
        setForm({
            clientId: row.clientId || '',
            clientName: row.clientName || '',
            employeeId: row.employeeId || '',
            employeeName: row.employeeName || '',
            program: row.program || '',
            sto: row.sto || '',
            date: row.date || '',
            status: row.status || 'Success',
        });
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setEditingEntry(null);
    };

    // Auto-fill client name when client is picked
    const handleClientChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const selected = clients.find(c => String(c.id) === e.target.value);
        setForm(f => ({
            ...f,
            clientId: selected ? `CLI-${selected.id}` : e.target.value,
            clientName: selected ? (selected.kidsName || selected.name || '') : '',
        }));
    };

    // ── Save (add / edit) ─────────────────────────────────────────
    const handleSave = async () => {
        setSaving(true);
        try {
            if (editingEntry) {
                const res = await fetch(`${DB_URL}/academic_baselines/${editingEntry.id}`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(form),
                });
                const saved = await res.json();
                setEntries(prev => prev.map(e => e.id === saved.id ? saved : e));
            } else {
                const res = await fetch(`${DB_URL}/academic_baselines`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(form),
                });
                const saved = await res.json();
                setEntries(prev => [...prev, saved]);
            }
            closeModal();
        } catch {
            alert('Could not save — is the shared database running on port 3001?');
        } finally {
            setSaving(false);
        }
    };

    // ── Delete ─────────────────────────────────────────────────────
    const handleDelete = async (id: number | string) => {
        if (!confirm('Delete this Academic Baseline entry?')) return;
        try {
            await fetch(`${DB_URL}/academic_baselines/${id}`, { method: 'DELETE' });
            setEntries(prev => prev.filter(e => e.id !== id));
        } catch {
            alert('Could not delete — is the shared database running on port 3001?');
        }
    };

    // ── Filtering / Sorting ────────────────────────────────────────
    const filteredByRules = useDataFilter({ data: entries, rules: filterRules, matchType });

    const filteredData = useMemo(() =>
        filteredByRules.filter(item =>
            Object.values(item).some(val =>
                String(val).toLowerCase().includes(searchQuery.toLowerCase())
            )
        ),
        [filteredByRules, searchQuery]
    );

    const sortedData = useMemo(() => {
        if (!sortConfig) return filteredData;
        return [...filteredData].sort((a: any, b: any) => {
            const aV = a[sortConfig.key] || '';
            const bV = b[sortConfig.key] || '';
            if (aV < bV) return sortConfig.direction === 'asc' ? -1 : 1;
            if (aV > bV) return sortConfig.direction === 'asc' ? 1 : -1;
            return 0;
        });
    }, [filteredData, sortConfig]);

    const handleSort = (key: string) => {
        setSortConfig(prev => ({
            key,
            direction: prev?.key === key && prev.direction === 'asc' ? 'desc' : 'asc',
        }));
    };

    // ── Render ─────────────────────────────────────────────────────
    return (
        <div className={styles.container}>
            {/* Toolbar */}
            <div className={styles.toolbar} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
                <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                    <div className={styles.searchBox}>
                        <Search size={20} color="var(--text-secondary-light)" />
                        <input
                            type="text"
                            placeholder="Search entries..."
                            className={styles.searchInput}
                            value={searchQuery}
                            onChange={e => setSearchQuery(e.target.value)}
                        />
                    </div>
                </div>

                <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                    <button className={styles.addBtn} onClick={openAdd}>
                        <Plus size={20} />
                        <span>Add Academic Baseline</span>
                    </button>
                    <button className={styles.filterBtn} onClick={() => setShowFilterDrawer(true)}>
                        <Filter size={16} color="currentColor" />
                        <span>Filter {filterRules.length > 0 && `(${filterRules.length})`}</span>
                    </button>
                </div>
            </div>

            {/* Filter Drawer */}
            <FilterDrawer
                isOpen={showFilterDrawer}
                onClose={() => setShowFilterDrawer(false)}
                storageKey="academic_baseline"
                columns={[
                    { id: 'clientId', label: 'Client ID' },
                    { id: 'clientName', label: 'Client Name' },
                    { id: 'employeeId', label: 'Employee ID' },
                    { id: 'employeeName', label: 'Employee Name' },
                    { id: 'program', label: 'Program' },
                    { id: 'sto', label: 'STO' },
                    { id: 'date', label: 'Date' },
                    { id: 'status', label: 'Status' },
                ]}
                rules={filterRules}
                matchType={matchType}
                onApply={(rules, type) => {
                    setFilterRules(rules);
                    setMatchType(type);
                    setShowFilterDrawer(false);
                }}
            />

            {/* Data Table */}
            <div className={styles.tableContainer}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            {[
                                { key: 'rowId', label: 'Row ID' },
                                { key: 'clientId', label: 'Client ID' },
                                { key: 'clientName', label: 'Client Name' },
                                { key: 'employeeId', label: 'Employee ID' },
                                { key: 'employeeName', label: 'Employee Name' },
                                { key: 'program', label: 'Program' },
                                { key: 'sto', label: 'STO' },
                                { key: 'date', label: 'Date' },
                                { key: 'status', label: 'Status' },
                            ].map(col => (
                                <th key={col.key} onClick={() => handleSort(col.key)} style={{ cursor: 'pointer', userSelect: 'none' }}>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                        {col.label}
                                        <ArrowUpDown size={14} color={sortConfig?.key === col.key ? 'var(--primary)' : 'var(--text-secondary-light)'} />
                                    </div>
                                </th>
                            ))}
                            <th style={{ width: '80px', textAlign: 'center' }}>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {sortedData.length > 0 ? sortedData.map(row => (
                            <tr key={row.id}>
                                <td>
                                    <span style={{ fontWeight: 700, color: 'var(--primary)', fontFamily: 'monospace', fontSize: '13px' }}>
                                        {row.rowId || '—'}
                                    </span>
                                </td>
                                <td><span style={{ fontWeight: 600 }}>{row.clientId}</span></td>
                                <td>{row.clientName}</td>
                                <td>{row.employeeId}</td>
                                <td>{row.employeeName}</td>
                                <td>{row.program}</td>
                                <td>{row.sto}</td>
                                <td>{row.date}</td>
                                <td>
                                    <span className={`${styles.statusBadge} ${row.status === 'Success' ? styles.success : styles.failed}`}>
                                        {row.status}
                                    </span>
                                </td>
                                <td>
                                    <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                                        <button className={styles.actionBtn} title="Edit" onClick={() => openEdit(row)}>
                                            <Pencil size={18} />
                                        </button>
                                        <button className={styles.actionBtn} style={{ color: 'var(--error)' }} title="Delete" onClick={() => handleDelete(row.id)}>
                                            <Trash2 size={18} />
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        )) : (
                            <tr>
                                <td colSpan={10} style={{ textAlign: 'center', padding: '32px', color: 'var(--text-secondary-light)' }}>
                                    No academic baseline entries found. Click "Add Academic Baseline" to create one.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
                <div style={{ position: 'sticky', bottom: 0, zIndex: 10, padding: '16px 24px', color: 'var(--text-secondary-light)', fontSize: '13px', borderTop: '1px solid var(--border-light)', backgroundColor: '#f9fafb', fontWeight: 500 }}>
                    Showing {sortedData.length} rows
                </div>
            </div>

            {/* ── Add / Edit Modal ───────────────────────────────────── */}
            {isModalOpen && (
                <div style={{
                    position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    zIndex: 1000,
                }}>
                    <div style={{
                        background: 'var(--surface-light, #fff)', borderRadius: '16px',
                        padding: '32px', width: '560px', maxWidth: '95vw', maxHeight: '90vh',
                        overflowY: 'auto', boxShadow: '0 20px 60px rgba(0,0,0,0.2)',
                        position: 'relative',
                    }}>
                        {/* Header */}
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
                            <h2 style={{ margin: 0, fontSize: '20px', fontWeight: 700 }}>
                                {editingEntry ? 'Edit Entry' : 'Add Academic Baseline'}
                            </h2>
                            <button onClick={closeModal} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '4px' }}>
                                <X size={24} />
                            </button>
                        </div>

                        {/* Form grid */}
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>

                            {/* Client — read-only info block */}
                            <div style={{ gridColumn: '1/-1' }}>
                                <label style={labelStyle}>Client</label>
                                {editingEntry ? (
                                    /* Editing: show locked info */
                                    <div style={readonlyGroupStyle}>
                                        <div style={readonlyChipStyle}>
                                            <span style={readonlyLabelStyle}>Name</span>
                                            <span style={readonlyValueStyle}>{form.clientName || '—'}</span>
                                        </div>
                                        <div style={readonlyChipStyle}>
                                            <span style={readonlyLabelStyle}>ID</span>
                                            <span style={readonlyValueStyle}>{form.clientId || '—'}</span>
                                        </div>
                                        <div style={lockBadgeStyle}>🔒 Locked</div>
                                    </div>
                                ) : (
                                    /* Adding: let user pick, then lock displayed values */
                                    <>
                                        <select style={inputStyle} onChange={handleClientChange}
                                            value={clients.find(c => `CLI-${c.id}` === form.clientId)?.id || ''}>
                                            <option value="">Select a client…</option>
                                            {clients.map(c => (
                                                <option key={c.id} value={c.id}>
                                                    {c.kidsName || c.name} — {c.clientId || `CLI-${c.id}`}
                                                </option>
                                            ))}
                                        </select>
                                        {form.clientId && (
                                            <div style={{ ...readonlyGroupStyle, marginTop: '8px' }}>
                                                <div style={readonlyChipStyle}>
                                                    <span style={readonlyLabelStyle}>Name</span>
                                                    <span style={readonlyValueStyle}>{form.clientName}</span>
                                                </div>
                                                <div style={readonlyChipStyle}>
                                                    <span style={readonlyLabelStyle}>ID</span>
                                                    <span style={readonlyValueStyle}>{form.clientId}</span>
                                                </div>
                                            </div>
                                        )}
                                    </>
                                )}
                            </div>

                            {/* Employee — always read-only */}
                            <div style={{ gridColumn: '1/-1' }}>
                                <label style={labelStyle}>Employee</label>
                                <div style={readonlyGroupStyle}>
                                    <div style={readonlyChipStyle}>
                                        <span style={readonlyLabelStyle}>Name</span>
                                        <span style={readonlyValueStyle}>{form.employeeName || '—'}</span>
                                    </div>
                                    <div style={readonlyChipStyle}>
                                        <span style={readonlyLabelStyle}>ID</span>
                                        <span style={readonlyValueStyle}>{form.employeeId || '—'}</span>
                                    </div>
                                    <div style={lockBadgeStyle}>🔒 Locked</div>
                                </div>
                            </div>

                            <div>
                                <label style={labelStyle}>Program</label>
                                <input style={inputStyle} value={form.program}
                                    onChange={e => setForm(f => ({ ...f, program: e.target.value }))} placeholder="e.g. Math Readiness" />
                            </div>

                            <div>
                                <label style={labelStyle}>STO</label>
                                <input style={inputStyle} value={form.sto}
                                    onChange={e => setForm(f => ({ ...f, sto: e.target.value }))} placeholder="e.g. Number Recognition 1-10" />
                            </div>

                            <div>
                                <label style={labelStyle}>Date</label>
                                <input type="date" style={inputStyle} value={form.date}
                                    onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />
                            </div>

                            <div>
                                <label style={labelStyle}>Status</label>
                                <select style={inputStyle} value={form.status}
                                    onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
                                    <option value="Success">Success</option>
                                    <option value="Failed">Failed</option>
                                    <option value="In Progress">In Progress</option>
                                    <option value="Pending">Pending</option>
                                </select>
                            </div>
                        </div>

                        {/* Footer buttons */}
                        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '28px' }}>
                            <button onClick={closeModal} style={cancelBtnStyle}>Cancel</button>
                            <button onClick={handleSave} disabled={saving} style={saveBtnStyle}>
                                {saving ? 'Saving…' : editingEntry ? 'Save Changes' : 'Create Entry'}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

// ── Inline styles ────────────────────────────────────────────────────
const labelStyle: React.CSSProperties = {
    display: 'block', fontSize: '12px', fontWeight: 600,
    color: 'var(--text-secondary-light)', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.5px',
};

const readonlyGroupStyle: React.CSSProperties = {
    display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap',
};

const readonlyChipStyle: React.CSSProperties = {
    display: 'flex', alignItems: 'center', gap: '6px',
    padding: '8px 14px', background: '#f1f5f9', borderRadius: '8px',
    border: '1px solid #e2e8f0',
};

const readonlyLabelStyle: React.CSSProperties = {
    fontSize: '11px', fontWeight: 700, color: '#94a3b8',
    textTransform: 'uppercase', letterSpacing: '0.04em',
};

const readonlyValueStyle: React.CSSProperties = {
    fontSize: '14px', fontWeight: 600, color: '#1e293b',
};

const lockBadgeStyle: React.CSSProperties = {
    marginLeft: 'auto', fontSize: '11px', color: '#94a3b8',
    padding: '4px 10px', background: '#f8fafc', borderRadius: '6px',
    border: '1px dashed #cbd5e1', fontWeight: 500,
};


const inputStyle: React.CSSProperties = {
    width: '100%', padding: '10px 12px', borderRadius: '8px',
    border: '1px solid var(--border-light, #e2e8f0)',
    background: 'var(--background-light, #f8fafc)',
    fontSize: '14px', color: 'var(--text-main, #1e293b)',
    boxSizing: 'border-box',
};

const cancelBtnStyle: React.CSSProperties = {
    padding: '10px 20px', borderRadius: '8px', border: '1px solid var(--border-light, #e2e8f0)',
    background: 'transparent', cursor: 'pointer', fontSize: '14px', fontWeight: 500,
};

const saveBtnStyle: React.CSSProperties = {
    padding: '10px 24px', borderRadius: '8px', border: 'none',
    background: 'var(--primary, #f6a800)', color: '#000',
    cursor: 'pointer', fontSize: '14px', fontWeight: 600,
};
