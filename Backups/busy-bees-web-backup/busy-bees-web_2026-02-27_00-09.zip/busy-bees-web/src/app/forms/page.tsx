import { redirect } from 'next/navigation';
export default function FormsPage() {
    redirect('/forms/academic-baseline');
}
