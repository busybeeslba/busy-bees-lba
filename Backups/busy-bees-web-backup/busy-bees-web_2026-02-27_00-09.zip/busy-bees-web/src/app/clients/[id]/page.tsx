'use client';

import { useState, useEffect, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import {
    ArrowLeft, Pencil, Phone, Mail, MapPin, Clock,
    FileText, BarChart2, BookOpen, Activity,
    ChevronRight, User, CheckCircle, XCircle, GripVertical
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Link from 'next/link';
import styles from './page.module.css';
import { MOCK_AVAILABLE_SERVICES } from '@/lib/mockData';
import AddClientModal from '@/components/clients/AddClientModal';

const DB_URL = 'http://localhost:3001';

function getInitials(name: string) {
    const parts = (name || '').trim().split(' ');
    if (parts.length >= 2) return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
    return (parts[0]?.[0] || '?').toUpperCase();
}

function calculateAge(dob: string) {
    if (!dob) return '—';
    const birth = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
    return age;
}

// Card definitions — order is persisted in state
const ALL_CARDS = ['contact', 'personal', 'education', 'program', 'services', 'forms'] as const;
type CardId = typeof ALL_CARDS[number];

const CARD_TITLES: Record<CardId, string> = {
    contact: 'Contact Information',
    personal: 'Personal Details',
    education: 'Education',
    program: 'Program',
    services: 'Services',
    forms: 'Forms',
};

export default function ClientDashboardPage() {
    const params = useParams();
    const router = useRouter();
    const clientId = decodeURIComponent(params.id as string);

    const [client, setClient] = useState<any>(null);
    const [forms, setForms] = useState<any[]>([]);
    const [activeFormTab, setActiveFormTab] = useState<'Academic Baseline' | 'Probe Data'>('Academic Baseline');
    const [loading, setLoading] = useState(true);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);

    // Drag-and-drop card layout: two columns
    const [leftCards, setLeftCards] = useState<CardId[]>(['contact', 'personal', 'education', 'program']);
    const [rightCards, setRightCards] = useState<CardId[]>(['services', 'forms']);

    const dragCard = useRef<CardId | null>(null);
    const dragFromCol = useRef<'left' | 'right' | null>(null);
    const dragOverCard = useRef<CardId | null>(null);
    const dragOverCol = useRef<'left' | 'right' | null>(null);

    const handleDragStart = (card: CardId, col: 'left' | 'right') => {
        dragCard.current = card;
        dragFromCol.current = col;
    };

    const handleDragOver = (e: React.DragEvent, card: CardId, col: 'left' | 'right') => {
        e.preventDefault();
        dragOverCard.current = card;
        dragOverCol.current = col;
    };

    const handleDragOverCol = (e: React.DragEvent, col: 'left' | 'right') => {
        e.preventDefault();
        dragOverCard.current = null;
        dragOverCol.current = col;
    };

    const handleDrop = () => {
        const from = dragCard.current;
        const fromCol = dragFromCol.current;
        const toCard = dragOverCard.current;
        const toCol = dragOverCol.current;
        if (!from || !fromCol || !toCol) return;

        const leftArr = [...leftCards];
        const rightArr = [...rightCards];

        // Remove from source
        if (fromCol === 'left') leftArr.splice(leftArr.indexOf(from), 1);
        else rightArr.splice(rightArr.indexOf(from), 1);

        // Insert into target
        if (toCard) {
            const targetArr = toCol === 'left' ? leftArr : rightArr;
            const idx = targetArr.indexOf(toCard);
            targetArr.splice(idx, 0, from);
        } else {
            // Drop on empty column area
            if (toCol === 'left') leftArr.push(from);
            else rightArr.push(from);
        }

        setLeftCards(leftArr);
        setRightCards(rightArr);

        dragCard.current = null;
        dragFromCol.current = null;
        dragOverCard.current = null;
        dragOverCol.current = null;
    };

    useEffect(() => {
        setLoading(true);
        Promise.all([
            fetch(`${DB_URL}/clients`).then(r => r.json()).catch(() => []),
            fetch(`${DB_URL}/academic_baselines`).then(r => r.json()).catch(() => []),
            fetch(`${DB_URL}/probes`).then(r => r.json()).catch(() => []),
        ]).then(([clients, baselines, probes]) => {
            const allClients = Array.isArray(clients) ? clients : [];

            // Match by clientId string OR numeric id (for clients created without a clientId field)
            let found = allClients.find((c: any) =>
                c.clientId === clientId || String(c.id) === clientId
            ) || null;

            // Defensive: parse programCategories if stored as JSON string
            if (found && typeof found.programCategories === 'string') {
                try { found = { ...found, programCategories: JSON.parse(found.programCategories) }; }
                catch { found = { ...found, programCategories: [] }; }
            }
            if (found && !Array.isArray(found.programCategories)) {
                found = { ...found, programCategories: [] };
            }

            setClient(found);

            if (found) {
                const cid = found.clientId || `CLI-${found.id}`;
                const matchesClient = (r: any) =>
                    r.clientId === cid ||
                    r.clientId === String(found!.id) ||
                    r.clientName === found!.kidsName ||
                    r.clientName === found!.name;
                const mapped = [
                    ...(Array.isArray(baselines) ? baselines : []).filter(matchesClient).map((r: any) => ({ ...r, formType: 'Academic Baseline' })),
                    ...(Array.isArray(probes) ? probes : []).filter(matchesClient).map((r: any) => ({ ...r, formType: 'Probe Data' })),
                ].sort((a, b) => (b.date || b.timestamp || '').localeCompare(a.date || a.timestamp || ''));
                setForms(mapped);
            }
        }).finally(() => setLoading(false));
    }, [clientId]);


    const handleSaveClient = async (data: any) => {
        try {
            const method = client?.id ? 'PATCH' : 'POST';
            const url = client?.id ? `${DB_URL}/clients/${client.id}` : `${DB_URL}/clients`;
            await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            });
            setClient({ ...client, ...data });
        } catch (e) {
            console.error('Failed to save client', e);
        }
        setIsEditModalOpen(false);
    };

    const getServiceName = (serviceId: string) => {
        const s = MOCK_AVAILABLE_SERVICES.find(x => x.serviceId === serviceId);
        return s?.name || serviceId;
    };

    const getProviderName = (serviceId: string) => {
        const s = MOCK_AVAILABLE_SERVICES.find(x => x.serviceId === serviceId);
        return s?.provider || 'Busy Bees';
    };

    if (loading) {
        return (
            <div className={styles.loadingContainer}>
                <div className={styles.loadingSpinner} />
                <p>Loading client dashboard…</p>
            </div>
        );
    }

    if (!client) {
        return (
            <div className={styles.loadingContainer}>
                <p style={{ color: '#ef4444', fontWeight: 600 }}>Client not found: {clientId}</p>
                <Link href="/clients" className={styles.backBtn}>← Back to Clients</Link>
            </div>
        );
    }

    const age = calculateAge(client.dob);
    const clientServices: any[] = Array.isArray(client.services) ? client.services : [];
    const activeFormForms = forms.filter(f => f.formType === activeFormTab);

    const buckets: Record<string, { Success: number; Failed: number }> = {};
    activeFormForms.forEach(f => {
        const d = f.date || (f.timestamp ? new Date(f.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : 'Unknown');
        if (!buckets[d]) buckets[d] = { Success: 0, Failed: 0 };
        if (f.status === 'Success') buckets[d].Success++;
        else buckets[d].Failed++;
    });
    const chartData = Object.entries(buckets).slice(-10).map(([date, v]) => ({ date, ...v }));
    const abCount = forms.filter(f => f.formType === 'Academic Baseline').length;
    const probeCount = forms.filter(f => f.formType === 'Probe Data').length;

    // Render a card by its ID
    const renderCard = (cardId: CardId, col: 'left' | 'right') => (
        <div
            key={cardId}
            className={styles.card}
            draggable
            onDragStart={() => handleDragStart(cardId, col)}
            onDragOver={(e) => handleDragOver(e, cardId, col)}
            onDrop={handleDrop}
        >
            <div className={styles.cardHeader}>
                <div className={styles.cardHeaderLeft}>
                    <span className={styles.dragHandle}><GripVertical size={14} /></span>
                    {cardId === 'contact' && <Mail size={14} className={styles.cardIcon} />}
                    {cardId === 'personal' && <User size={14} className={styles.cardIcon} />}
                    {cardId === 'education' && <BookOpen size={14} className={styles.cardIcon} />}
                    {cardId === 'program' && <BarChart2 size={14} className={styles.cardIcon} />}
                    {cardId === 'services' && <Activity size={14} className={styles.cardIcon} />}
                    {cardId === 'forms' && <FileText size={14} className={styles.cardIcon} />}
                    {CARD_TITLES[cardId]}
                </div>
                {cardId === 'services' && (
                    <span className={styles.cardBadge}>{clientServices.length}</span>
                )}
            </div>
            <div className={cardId === 'services' || cardId === 'forms' ? styles.cardBodyNoPad : styles.cardBody}>
                {cardId === 'contact' && renderContact()}
                {cardId === 'personal' && renderPersonal(age)}
                {cardId === 'education' && renderEducation()}
                {cardId === 'program' && renderProgram()}
                {cardId === 'services' && renderServices(clientServices, getProviderName, getServiceName)}
                {cardId === 'forms' && renderForms({
                    forms, activeFormTab, setActiveFormTab, activeFormForms, chartData, abCount, probeCount, styles
                })}
            </div>
        </div>
    );

    const renderContact = () => (
        <>
            {Array.isArray(client.emails) && client.emails.length > 0 && (
                <div className={styles.contactGroup}>
                    <div className={styles.contactGroupLabel}>Email</div>
                    {[...client.emails].sort((a: any, b: any) => (b.isPrimary ? 1 : 0) - (a.isPrimary ? 1 : 0)).map((e: any) => (
                        <div key={e.id} className={styles.contactRow}>
                            {e.isPrimary ? <span className={styles.primaryDot}>P</span> : <span className={styles.primaryDotEmpty} />}
                            <span className={styles.contactValue}>{e.value}</span>
                            <span className={styles.contactType}>{e.type}</span>
                            {e.isPrimary && <a href={`mailto:${e.value}`} className={styles.contactAction}><Mail size={13} /></a>}
                        </div>
                    ))}
                </div>
            )}
            {Array.isArray(client.phones) && client.phones.length > 0 && (
                <div className={styles.contactGroup}>
                    <div className={styles.contactGroupLabel}>Phone</div>
                    {[...client.phones].sort((a: any, b: any) => (b.isPrimary ? 1 : 0) - (a.isPrimary ? 1 : 0)).map((p: any) => (
                        <div key={p.id} className={styles.contactRow}>
                            {p.isPrimary ? <span className={styles.primaryDot}>P</span> : <span className={styles.primaryDotEmpty} />}
                            <span className={styles.contactValue}>{p.value}</span>
                            <span className={styles.contactType}>{p.type}</span>
                            {p.isPrimary && <a href={`tel:${p.value}`} className={styles.contactAction}><Phone size={13} /></a>}
                        </div>
                    ))}
                </div>
            )}
            {Array.isArray(client.addresses) && client.addresses.length > 0 && (
                <div className={styles.contactGroup}>
                    <div className={styles.contactGroupLabel}>Address</div>
                    {[...client.addresses].sort((a: any, b: any) => (b.isPrimary ? 1 : 0) - (a.isPrimary ? 1 : 0)).map((a: any) => (
                        <div key={a.id} className={styles.contactRow}>
                            {a.isPrimary ? <span className={styles.primaryDot}>P</span> : <span className={styles.primaryDotEmpty} />}
                            <span className={styles.contactValue}>{a.value}</span>
                            <span className={styles.contactType}>{a.type}</span>
                            {a.isPrimary && <a href={`https://maps.google.com/?q=${encodeURIComponent(a.value)}`} target="_blank" rel="noreferrer" className={styles.contactAction}><MapPin size={13} /></a>}
                        </div>
                    ))}
                </div>
            )}
        </>
    );

    const renderPersonal = (age: string | number) => (
        <div className={styles.detailsGrid}>
            <div className={styles.detailItem}>
                <span className={styles.detailLabel}>Date of Birth</span>
                <span className={styles.detailValue}>{client.dob || '—'}</span>
            </div>
            <div className={styles.detailItem}>
                <span className={styles.detailLabel}>Age</span>
                <span className={styles.detailValue}>{age}</span>
            </div>
        </div>
    );

    const renderEducation = () => (
        <div className={styles.detailsGrid}>
            <div className={styles.detailItem}>
                <span className={styles.detailLabel}>Teacher</span>
                <span className={styles.detailValue}>{client.teacher || '—'}</span>
            </div>
            <div className={styles.detailItem}>
                <span className={styles.detailLabel}>IEP Meeting</span>
                <span className={styles.detailValue}>{client.iepMeeting || '—'}</span>
            </div>
        </div>
    );

    const renderProgram = () => (
        <>
            <div className={styles.detailsGrid}>
                <div className={styles.detailItem}>
                    <span className={styles.detailLabel}>Program Description</span>
                    <span className={styles.detailValue}>{client.assignedPrograms || '—'}</span>
                </div>
                <div className={styles.detailItem}>
                    <span className={styles.detailLabel}>Program %</span>
                    <span className={styles.detailValue}>{client.programPercentage || '—'}</span>
                </div>
            </div>
            {Array.isArray(client.programCategories) && client.programCategories.length > 0 && (
                <div className={styles.programCatsSection}>
                    <div className={styles.detailLabel} style={{ marginBottom: '8px' }}>Program Categories</div>
                    <div className={styles.programCatsList}>
                        {client.programCategories.map((cat: any) => (
                            <div key={cat.id} className={styles.programCatCard}>
                                <div className={styles.programCatName}>{cat.name}</div>
                                {Array.isArray(cat.targets) && cat.targets.length > 0 && (
                                    <div className={styles.programCatTargets}>
                                        {cat.targets.map((t: any) => (
                                            <span key={t.id} className={styles.programCatTarget}>{t.name}</span>
                                        ))}
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </>
    );

    const renderServices = (
        clientServices: any[],
        getProviderName: (id: string) => string,
        getServiceName: (id: string) => string
    ) => (
        clientServices.length === 0 ? (
            <p className={styles.emptyText}>No services assigned.</p>
        ) : (
            <table className={styles.servicesTable}>
                <thead>
                    <tr>
                        <th>Provider</th>
                        <th>Service</th>
                        <th>Hours</th>
                        <th>Used</th>
                        <th>Remaining</th>
                    </tr>
                </thead>
                <tbody>
                    {clientServices.map((srv: any, i: number) => (
                        <tr key={i}>
                            <td><span className={styles.providerChip}>{getProviderName(srv.serviceId)}</span></td>
                            <td className={styles.srvName}>{getServiceName(srv.serviceId)}</td>
                            <td><span className={styles.hoursBadge}><Clock size={12} /> {srv.hours}</span></td>
                            <td className={styles.usedCell}>0h</td>
                            <td className={styles.remainingCell}>{srv.hours}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        )
    );

    return (
        <div className={styles.page}>
            {/* ── Header ── */}
            <div className={styles.pageHeader}>
                <div className={styles.headerLeft}>
                    <button className={styles.backBtn} onClick={() => router.back()}>
                        <ArrowLeft size={17} />
                        <span>Clients</span>
                    </button>
                    <ChevronRight size={15} className={styles.breadcrumbSep} />
                    <span className={styles.breadcrumbCurrent}>{client.kidsName}</span>
                </div>
                <div className={styles.headerRight}>
                    <span className={`${styles.statusBadge} ${client.status === 'Active' ? styles.statusActive : styles.statusInactive}`}>
                        {client.status}
                    </span>
                    <button className={styles.editBtn} onClick={() => setIsEditModalOpen(true)}>
                        <Pencil size={14} />
                        Edit Client
                    </button>
                </div>
            </div>

            {/* ── Hero Card ── */}
            <div className={styles.heroCard}>
                <div className={styles.heroAvatar}>
                    {getInitials(client.kidsName)}
                </div>

                <div className={styles.heroInfo}>
                    <div className={styles.heroMeta}>
                        <div className={styles.heroMetaItem}>
                            <span className={styles.heroMetaLabel}>Child Name</span>
                            <h1 className={styles.heroName}>{client.kidsName}</h1>
                        </div>
                        <div className={styles.heroMetaDivider} />
                        <div className={styles.heroMetaItem}>
                            <span className={styles.heroMetaLabel}>Guardian</span>
                            <span className={styles.heroGuardian}>{client.guardian} {client.guardianLastName}</span>
                        </div>
                        <div className={styles.heroMetaDivider} />
                        <div className={styles.heroMetaItem}>
                            <span className={styles.heroMetaLabel}>Client ID</span>
                            <span className={styles.heroClientId}>{client.clientId}</span>
                        </div>
                    </div>
                </div>

                {/* Stat strip */}
                <div className={styles.heroStats}>
                    <div className={styles.heroStat}>
                        <span className={styles.heroStatValue}>{age}</span>
                        <span className={styles.heroStatLabel}>Age</span>
                    </div>
                    <div className={styles.heroStatDivider} />
                    <div className={styles.heroStat}>
                        <span className={styles.heroStatValue}>{clientServices.length}</span>
                        <span className={styles.heroStatLabel}>Services</span>
                    </div>
                    <div className={styles.heroStatDivider} />
                    <div className={styles.heroStat}>
                        <span className={styles.heroStatValue}>{abCount}</span>
                        <span className={styles.heroStatLabel}>Baselines</span>
                    </div>
                    <div className={styles.heroStatDivider} />
                    <div className={styles.heroStat}>
                        <span className={styles.heroStatValue}>{probeCount}</span>
                        <span className={styles.heroStatLabel}>Probes</span>
                    </div>
                </div>
            </div>

            {/* ── Drag hint ── */}
            <div className={styles.dragHint}>
                <GripVertical size={13} /> Drag cards to rearrange them between columns
            </div>

            {/* ── Main content grid ── */}
            <div className={styles.contentGrid}>
                {/* LEFT COLUMN */}
                <div
                    className={styles.leftCol}
                    onDragOver={(e) => handleDragOverCol(e, 'left')}
                    onDrop={handleDrop}
                >
                    {leftCards.map(id => renderCard(id, 'left'))}
                </div>

                {/* RIGHT COLUMN */}
                <div
                    className={styles.rightCol}
                    onDragOver={(e) => handleDragOverCol(e, 'right')}
                    onDrop={handleDrop}
                >
                    {rightCards.map(id => renderCard(id, 'right'))}
                </div>
            </div>

            {/* Edit Client Modal */}
            <AddClientModal
                isOpen={isEditModalOpen}
                onClose={() => setIsEditModalOpen(false)}
                onSave={handleSaveClient}
                initialData={client}
            />
        </div>
    );
}

// ── Forms card renderer (extracted for clarity) ──────────────────────────────
function renderForms({
    forms, activeFormTab, setActiveFormTab, activeFormForms, chartData, abCount, probeCount, styles
}: {
    forms: any[];
    activeFormTab: 'Academic Baseline' | 'Probe Data';
    setActiveFormTab: (t: 'Academic Baseline' | 'Probe Data') => void;
    activeFormForms: any[];
    chartData: any[];
    abCount: number;
    probeCount: number;
    styles: any;
}) {
    return (
        <>
            {/* Tabs */}
            <div className={styles.formTabs}>
                {(['Academic Baseline', 'Probe Data'] as const).map(tab => {
                    const count = tab === 'Academic Baseline' ? abCount : probeCount;
                    const isActive = activeFormTab === tab;
                    const color = tab === 'Academic Baseline' ? '#2563eb' : '#7c3aed';
                    const bg = tab === 'Academic Baseline' ? '#eff6ff' : '#f5f3ff';
                    return (
                        <button
                            key={tab}
                            className={`${styles.formTab} ${isActive ? styles.formTabActive : ''}`}
                            style={isActive ? { borderColor: color, color } : {}}
                            onClick={() => setActiveFormTab(tab)}
                        >
                            {tab === 'Academic Baseline' ? '📋' : '🔬'} {tab}
                            <span className={styles.formTabBadge} style={{ background: bg, color }}>{count}</span>
                        </button>
                    );
                })}
            </div>
            <div className={styles.cardBody} style={{ paddingTop: '16px' }}>
                {activeFormForms.length === 0 ? (
                    <p className={styles.emptyText}>No {activeFormTab} records yet.</p>
                ) : (
                    <>
                        <div className={styles.chartWrap}>
                            <div className={styles.chartTitle}>Status Overview by Date</div>
                            <ResponsiveContainer width="100%" height={180}>
                                <LineChart data={chartData} margin={{ top: 4, right: 12, left: -20, bottom: 0 }}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                                    <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                                    <YAxis allowDecimals={false} tick={{ fontSize: 10, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                                    <Tooltip contentStyle={{ borderRadius: '10px', border: '1px solid #e2e8f0', fontSize: '12px' }} cursor={{ stroke: '#e2e8f0' }} />
                                    <Legend wrapperStyle={{ fontSize: '11px' }} />
                                    <Line type="monotone" dataKey="Success" stroke="#34a853" strokeWidth={2.5} dot={{ r: 3, fill: '#34a853', strokeWidth: 0 }} activeDot={{ r: 5 }} />
                                    <Line type="monotone" dataKey="Failed" stroke="#ea4335" strokeWidth={2.5} strokeDasharray="5 3" dot={{ r: 3, fill: '#ea4335', strokeWidth: 0 }} activeDot={{ r: 5 }} />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                        <table className={styles.formsTable}>
                            <thead>
                                <tr>
                                    <th>Row ID</th><th>Date</th><th>Program</th><th>STO</th><th>Status</th><th>Employee</th>
                                </tr>
                            </thead>
                            <tbody>
                                {activeFormForms.map((f: any, i: number) => (
                                    <tr key={f.id || i}>
                                        <td><span className={styles.rowId}>{f.rowId || '—'}</span></td>
                                        <td className={styles.dateCell}>{f.date || (f.timestamp ? new Date(f.timestamp).toLocaleDateString() : '—')}</td>
                                        <td>{f.program || '—'}</td>
                                        <td className={styles.stoCell} title={f.sto}>{f.sto || '—'}</td>
                                        <td>
                                            <span className={`${styles.statusPill} ${f.status === 'Success' ? styles.pillSuccess : styles.pillFailed}`}>
                                                {f.status === 'Success' ? <CheckCircle size={10} /> : <XCircle size={10} />}
                                                {f.status || '—'}
                                            </span>
                                        </td>
                                        <td>{f.employeeName || '—'}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </>
                )}
            </div>
        </>
    );
}
