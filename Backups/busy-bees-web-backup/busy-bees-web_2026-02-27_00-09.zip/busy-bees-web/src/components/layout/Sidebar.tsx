'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';
import { LayoutDashboard, Users, Calendar, FileText, Settings, LogOut, Building2, Wrench, ClipboardCheck, ChevronDown, ChevronRight } from 'lucide-react';
import { useSidebar } from '@/context/SidebarContext';
import styles from './Sidebar.module.css';

const MENU_ITEMS = [
    { name: 'Dashboard', icon: LayoutDashboard, path: '/' },
    {
        name: 'Employees',
        icon: Users,
        path: '/employees',
        subItems: [
            { name: 'Staff List', path: '/employees' },
            { name: 'Role Management', path: '/employees/roles' },
        ],
    },

    { name: 'Clients', icon: Building2, path: '/clients' },
    {
        name: 'Services',
        icon: Wrench,
        path: '/services',
        subItems: [
            { name: 'Service List', path: '/services/list' },
            { name: 'Client Services', path: '/services/client-services' },
        ],
    },
    {
        name: 'Forms',
        icon: ClipboardCheck,
        path: '/forms',
        subItems: [
            { name: 'Academic Baseline', path: '/forms/academic-baseline' },
            { name: 'Probe', path: '/forms/probe' },
        ]
    },
    { name: 'Session Summary', icon: FileText, path: '/session-summary' },
    { name: 'Calendar', icon: Calendar, path: '/calendar' },
    { name: 'Reports', icon: FileText, path: '/reports' },
    { name: 'Settings', icon: Settings, path: '/settings' },
];

export default function Sidebar() {
    const pathname = usePathname();
    const { isCollapsed } = useSidebar();
    const [openMenus, setOpenMenus] = useState<Record<string, boolean>>({
        '/employees': pathname.startsWith('/employees'),
        '/services': pathname.startsWith('/services'),
        '/forms': pathname.startsWith('/forms')
    });

    const toggleMenu = (path: string) => {
        setOpenMenus(prev => ({ ...prev, [path]: !prev[path] }));
    };

    return (
        <aside className={`${styles.sidebar} ${isCollapsed ? styles.collapsed : ''}`}>
            <div className={styles.logo}>
                <div className={styles.logoIcon}>🐝</div>
                {!isCollapsed && <h1>Busy Bees</h1>}
            </div>

            <nav className={styles.nav}>
                {MENU_ITEMS.map((item) => {
                    const Icon = item.icon;
                    const isActive = item.subItems
                        ? pathname.startsWith(item.path)
                        : pathname === item.path;

                    if (item.subItems) {
                        const isOpen = openMenus[item.path];
                        return (
                            <div key={item.path} className={styles.navGroup}>
                                <button
                                    className={`${styles.navItem} ${isActive && !isOpen ? styles.active : ''}`}
                                    onClick={() => toggleMenu(item.path)}
                                    title={isCollapsed ? item.name : ''}
                                >
                                    <Icon size={20} />
                                    {!isCollapsed && (
                                        <>
                                            <span style={{ flex: 1, textAlign: 'left' }}>{item.name}</span>
                                            {isOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                                        </>
                                    )}
                                </button>
                                {!isCollapsed && isOpen && (
                                    <div className={styles.subMenu}>
                                        {item.subItems.map((subItem) => (
                                            <Link
                                                key={subItem.path}
                                                href={subItem.path}
                                                className={`${styles.subMenuItem} ${pathname === subItem.path ? styles.activeSubMenu : ''}`}
                                            >
                                                {subItem.name}
                                            </Link>
                                        ))}
                                    </div>
                                )}
                            </div>
                        );
                    }

                    return (
                        <Link
                            key={item.path}
                            href={item.path}
                            className={`${styles.navItem} ${isActive ? styles.active : ''}`}
                            title={isCollapsed ? item.name : ''}
                        >
                            <Icon size={20} />
                            {!isCollapsed && <span>{item.name}</span>}
                        </Link>
                    );
                })}
            </nav>

            <div className={styles.footer}>
                <button className={styles.logoutBtn} title={isCollapsed ? 'Logout' : ''}>
                    <LogOut size={18} />
                    {!isCollapsed && <span>Logout</span>}
                </button>
            </div>
        </aside>
    );
}
